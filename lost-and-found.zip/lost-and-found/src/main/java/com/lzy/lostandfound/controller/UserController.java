package com.lzy.lostandfound.controller;

import com.lzy.lostandfound.entity.LostInfo;
import com.lzy.lostandfound.entity.User;
import com.lzy.lostandfound.service.IUserService;
import com.lzy.lostandfound.utils.JwtUtil;
import com.lzy.lostandfound.utils.Md5Util;
import com.lzy.lostandfound.utils.ThreadLocalUtil;
import com.lzy.lostandfound.vo.Result;
import com.lzy.lostandfound.vo.Tu;
import jakarta.validation.constraints.Pattern;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.web.bind.annotation.*;
import org.springframework.stereotype.Controller;

import javax.swing.text.Utilities;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * <p>
 * 用户表 前端控制器
 * </p>
 *
 * @author baomidou
 * @since 2025-10-16
 */
@RestController
public class UserController {
    @Autowired
    private IUserService userService;
    @Autowired
    private StringRedisTemplate redisTemplate;
    @PostMapping("/auth/register")
    public Result register(@RequestBody User user) {

         user.setCreateTime(LocalDateTime.now());
         user.setUpdateTime(LocalDateTime.now());
        User u= userService.query().eq("username",user.getUsername()).one();
        if(u!=null){
            return Result.error("用户名已存在");
        }
        else{
            String md5Password = Md5Util.getMD5String(user.getPassword());
            user.setPassword(md5Password);
           userService.save(user);

            return Result.success();
        }



    }
    @PostMapping("/auth/login")
    public Result login(  @RequestParam String username,
                          @RequestParam String password) {
        User u = userService.query().eq("username", username).one();
        if (u == null) {
            return Result.error("用户名不存在");
        } else if (!Md5Util.checkPassword(password, u.getPassword())) {         // 密码错误
            return Result.error("密码错误");
        } else {
            Map<String,Object> claims=new HashMap<>();
            claims.put("username",username);
            claims.put("id",u.getId());
            String token  = JwtUtil.genToken(claims);
            //
            //把token存入redis种
            ValueOperations<String, String> operations = redisTemplate.opsForValue();
            operations.set(token, token, 12, TimeUnit.HOURS);//等于token过期时间`
            System.out.println(token);
            Tu tu=new Tu();
            tu.setToken(token);
            tu.setUser(u);
            return Result.success(tu);
        }
    }
    @GetMapping("/user/info")
    public Result getUserInfo() {
        // 从token中获取用户信息
       Map<String,Object> map= ThreadLocalUtil.get();
       map.get("username");
      User user =   userService.query().eq("username",map.get("username")).one();

        return Result.success(user);     // 这里返回用户信息
    }
    @PostMapping("/user/update")
    public Result updateUser(@RequestBody User userUpdate) {
        try {
            // 从token中获取当前登录用户ID
            Map<String,Object> map = ThreadLocalUtil.get();
            String userId = map.get("id").toString();

            // 获取当前用户信息
            User currentUser = userService.getById(userId);

            // 更新字段 - 确保处理前端传递的所有可能字段
            if (userUpdate.getName() != null) {
                currentUser.setName(userUpdate.getName());
            }
            if (userUpdate.getEmail() != null) {
                currentUser.setEmail(userUpdate.getEmail());
            }
            if (userUpdate.getPhone() != null) {
                currentUser.setPhone(userUpdate.getPhone());
            }
            if (userUpdate.getUsername() != null) {
                // 检查用户名是否已被占用
                User existingUser = userService.query().eq("username", userUpdate.getUsername()).ne("id", userId).one();
                if (existingUser != null) {
                    return Result.error("用户名已被占用");
                }
                currentUser.setUsername(userUpdate.getUsername());
            }

            currentUser.setUpdateTime(LocalDateTime.now());

            userService.updateById(currentUser);

            // 返回更新后的用户信息，不包含密码
            currentUser.setPassword(null);
            return Result.success(currentUser);
        } catch (Exception e) {
            e.printStackTrace();
            return Result.error("更新用户信息失败");
        }
    }

}
