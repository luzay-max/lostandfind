package com.lzy.lostandfound.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.lzy.lostandfound.entity.FindInfo;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 * 招领信息表 Mapper 接口
 * </p>
 *
 * @author baomidou
 * @since 2025-10-16
 */
@Mapper
public interface FindInfoMapper extends BaseMapper<FindInfo> {

}
