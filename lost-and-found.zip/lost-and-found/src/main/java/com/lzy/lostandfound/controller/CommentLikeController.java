package com.lzy.lostandfound.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 评论点赞表 前端控制器
 * </p>
 *
 * @author baomidou
 * @since 2025-10-16
 */
@RestController
@RequestMapping("/dao/commentLike")
public class CommentLikeController {

}
