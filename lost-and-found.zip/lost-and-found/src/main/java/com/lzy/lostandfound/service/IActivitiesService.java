package com.lzy.lostandfound.service;

import com.lzy.lostandfound.entity.Activities;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 用户活动日志表 服务类
 * </p>
 *
 * @author baomidou
 * @since 2025-11-05
 */
public interface IActivitiesService extends IService<Activities> {

}
