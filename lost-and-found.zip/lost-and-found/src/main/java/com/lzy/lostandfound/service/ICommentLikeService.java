package com.lzy.lostandfound.service;

import com.lzy.lostandfound.entity.CommentLike;
import com.baomidou.mybatisplus.extension.service.IService;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 评论点赞表 服务类
 * </p>
 *
 * @author baomidou
 * @since 2025-10-16
 */

public interface ICommentLikeService extends IService<CommentLike> {

}
