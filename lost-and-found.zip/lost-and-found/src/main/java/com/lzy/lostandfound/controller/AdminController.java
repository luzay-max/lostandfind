package com.lzy.lostandfound.controller;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.lzy.lostandfound.entity.Activities;
import com.lzy.lostandfound.entity.LostInfo;
import com.lzy.lostandfound.service.IActivitiesService;
import com.lzy.lostandfound.service.IFindInfoService;
import com.lzy.lostandfound.service.ILostInfoService;
import com.lzy.lostandfound.service.IUserService;
import com.lzy.lostandfound.vo.IdAndType;
import com.lzy.lostandfound.vo.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.*;

@CrossOrigin(origins = "http://localhost:5174")
@RestController
@RequestMapping("/audit")
public class AdminController {
    @Autowired
    private IUserService userService;
    @Autowired
    private ILostInfoService lostInfoService;
    @Autowired
    private IFindInfoService findInfoService;
    @Autowired
    private IActivitiesService activitiesService;

    @GetMapping("/list")
    public Result getList(
            @RequestParam(defaultValue = "1") Integer page,
            @RequestParam(defaultValue = "10") Integer pageSize,
            @RequestParam(required = false) String type, // lost / find / all
            @RequestParam(required = false) String keyword,
            @RequestParam(required = false, defaultValue = "PENDING") String status,
            @RequestParam(required = false) Long startTime,
            @RequestParam(required = false) Long endTime) {
        try {
            ZoneId zoneId = ZoneId.of("Asia/Shanghai");
            LocalDateTime startDt = null, endDt = null;
            if (startTime != null && endTime != null) {
                startDt = Instant.ofEpochMilli(startTime).atZone(zoneId).toLocalDateTime();
                endDt = Instant.ofEpochMilli(endTime).atZone(zoneId).toLocalDateTime();
            }

            // 🧩 结果列表
            List<Map<String, Object>> mergedList = new ArrayList<>();

            // ========== 查询失物 ==========
            if (!"find".equalsIgnoreCase(type)) {
                LambdaQueryWrapper<LostInfo> lostWrapper = new LambdaQueryWrapper<>();
                lostWrapper.eq(LostInfo::getStatus, status);
                if (keyword != null && !keyword.isEmpty()) {
                    lostWrapper.and(q -> q.like(LostInfo::getName, keyword)
                            .or().like(LostInfo::getDescription, keyword));
                }
                if (startDt != null && endDt != null) {
                    lostWrapper.between(LostInfo::getPublishTime, startDt, endDt);
                }
                lostWrapper.orderByDesc(LostInfo::getPublishTime);
                List<LostInfo> lostList = lostInfoService.list(lostWrapper);

                // 转为统一结构
                for (LostInfo info : lostList) {
                    Map<String, Object> item = new HashMap<>();
                    item.put("id", info.getId());
                    item.put("name", info.getName());
                    item.put("description", info.getDescription());
                    item.put("status", info.getStatus());
                    item.put("publishTime", info.getPublishTime());
                    item.put("type", "lost"); // 区分来源
                    mergedList.add(item);
                }
            }

            // ========== 查询招领 ==========
            if (!"lost".equalsIgnoreCase(type)) {
                LambdaQueryWrapper<com.lzy.lostandfound.entity.FindInfo> findWrapper = new LambdaQueryWrapper<>();
                findWrapper.eq(com.lzy.lostandfound.entity.FindInfo::getStatus, status);
                if (keyword != null && !keyword.isEmpty()) {
                    findWrapper.and(q -> q.like(com.lzy.lostandfound.entity.FindInfo::getName, keyword)
                            .or().like(com.lzy.lostandfound.entity.FindInfo::getDescription, keyword));
                }
                if (startDt != null && endDt != null) {
                    findWrapper.between(com.lzy.lostandfound.entity.FindInfo::getPublishTime, startDt, endDt);
                }
                findWrapper.orderByDesc(com.lzy.lostandfound.entity.FindInfo::getPublishTime);
                List<com.lzy.lostandfound.entity.FindInfo> findList = findInfoService.list(findWrapper);

                for (com.lzy.lostandfound.entity.FindInfo info : findList) {
                    Map<String, Object> item = new HashMap<>();
                    item.put("id", info.getId());
                    item.put("name", info.getName());
                    item.put("description", info.getDescription());
                    item.put("status", info.getStatus());
                    item.put("publishTime", info.getPublishTime());
                    item.put("type", "find");
                    mergedList.add(item);
                }
            }

            // ========== 统一排序（按时间降序） ==========
            mergedList.sort((a, b) -> {
                LocalDateTime t1 = (LocalDateTime) a.get("publishTime");
                LocalDateTime t2 = (LocalDateTime) b.get("publishTime");
                return t2.compareTo(t1);
            });

            // ========== 手动分页 ==========
            int total = mergedList.size();
            int fromIndex = (page - 1) * pageSize;
            int toIndex = Math.min(fromIndex + pageSize, total);
            List<Map<String, Object>> pagedList =
                    fromIndex >= total ? Collections.emptyList() : mergedList.subList(fromIndex, toIndex);

            return Result.success(Map.of(
                    "list", pagedList,
                    "total", total
            ));
        } catch (Exception e) {
            e.printStackTrace();
            return Result.error("获取审核列表失败");
        }
    }

    @PostMapping("/pass")
    public Result pass(@RequestBody IdAndType idAndType){

        if ("lost".equalsIgnoreCase(idAndType.getType())) {
            LostInfo lostInfo = lostInfoService.getById(idAndType.getId());
            lostInfo.setStatus("APPROVED");

            lostInfoService.updateById(lostInfo);
            // ✅ 插入活动记录
            Activities act = new Activities();
            act.setId(UUID.randomUUID().toString());
            act.setUserId(lostInfo.getUserId());
            act.setAction("PUBLISH");
            act.setItemType("lost");
            act.setItemId(lostInfo.getId());
            act.setContent("发布了失物信息：" + lostInfo.getName());
            act.setCreateTime(LocalDateTime.now());
            activitiesService.save(act);

        } else if ("find".equalsIgnoreCase(idAndType.getType())) {
            com.lzy.lostandfound.entity.FindInfo findInfo = findInfoService.getById(idAndType.getId());
            findInfo.setStatus("APPROVED");
            findInfoService.updateById(findInfo);
            // ✅ 插入审核通过后发布活动日志
            Activities act = new Activities();
            act.setId(UUID.randomUUID().toString());
            act.setUserId(findInfo.getUserId());
            act.setAction("PUBLISH");
            act.setItemType("find");
            act.setItemId(findInfo.getId());
            act.setContent("发布了招领信息：" + findInfo.getName());
            act.setCreateTime(LocalDateTime.now());
            activitiesService.save(act);
        } else {
            return Result.error("类型错误");
        }
        return Result.success();
    }

    @PostMapping("/batchPass")
    public Result batchPass(@RequestBody List<IdAndType> idAndTypeList) {
        try {
            for (IdAndType idAndType : idAndTypeList) {
                if ("lost".equalsIgnoreCase(idAndType.getType())) {
                    LostInfo lostInfo = lostInfoService.getById(idAndType.getId());
                    if (lostInfo != null) {
                        lostInfo.setStatus("APPROVED");
                        lostInfoService.updateById(lostInfo);
                        Activities act = new Activities();
                        act.setId(UUID.randomUUID().toString());
                        act.setUserId(lostInfo.getUserId());
                        act.setAction("PUBLISH");
                        act.setItemType("lost");
                        act.setItemId(lostInfo.getId());
                        act.setContent("发布了失物信息：" + lostInfo.getName());
                        act.setCreateTime(LocalDateTime.now());
                        activitiesService.save(act);
                    }
                } else if ("find".equalsIgnoreCase(idAndType.getType())) {
                    com.lzy.lostandfound.entity.FindInfo findInfo = findInfoService.getById(idAndType.getId());
                    if (findInfo != null) {
                        findInfo.setStatus("APPROVED");
                        findInfoService.updateById(findInfo);
                        // ✅ 插入审核通过后发布活动日志
                        Activities act = new Activities();
                        act.setId(UUID.randomUUID().toString());
                        act.setUserId(findInfo.getUserId());
                        act.setAction("PUBLISH");
                        act.setItemType("find");
                        act.setItemId(findInfo.getId());
                        act.setContent("发布了招领信息：" + findInfo.getName());
                        act.setCreateTime(LocalDateTime.now());
                        activitiesService.save(act);
                    }
                }
            }
            return Result.success("批量通过成功");
        } catch (Exception e) {
            e.printStackTrace();
            return Result.error("批量通过失败");
        }
    }

    @PostMapping("/reject")
    public Result reject(@RequestBody IdAndType idAndType){

        if ("lost".equalsIgnoreCase(idAndType.getType())) {
            LostInfo lostInfo = lostInfoService.getById(idAndType.getId());
            lostInfo.setStatus("REJECTED");

            lostInfoService.updateById(lostInfo);
        } else if ("find".equalsIgnoreCase(idAndType.getType())) {
            com.lzy.lostandfound.entity.FindInfo findInfo = findInfoService.getById(idAndType.getId());
            findInfo.setStatus("REJECTED");
            findInfoService.updateById(findInfo);
        } else {
            return Result.error("类型错误");
        }
        return Result.success();
    }





}
