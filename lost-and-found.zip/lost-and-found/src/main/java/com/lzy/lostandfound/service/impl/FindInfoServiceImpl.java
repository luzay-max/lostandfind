package com.lzy.lostandfound.service.impl;

import com.lzy.lostandfound.entity.FindInfo;
import com.lzy.lostandfound.mapper.FindInfoMapper;
import com.lzy.lostandfound.service.IFindInfoService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 招领信息表 服务实现类
 * </p>
 *
 * @author baomidou
 * @since 2025-10-16
 */
@Service
public class FindInfoServiceImpl extends ServiceImpl<FindInfoMapper, FindInfo> implements IFindInfoService {

}
