package com.lzy.lostandfound.service.impl;

import com.lzy.lostandfound.entity.LostInfo;
import com.lzy.lostandfound.mapper.LostInfoMapper;
import com.lzy.lostandfound.service.ILostInfoService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 失物信息表 服务实现类
 * </p>
 *
 * @author baomidou
 * @since 2025-10-16
 */
@Service
public class LostInfoServiceImpl extends ServiceImpl<LostInfoMapper, LostInfo> implements ILostInfoService {

}
