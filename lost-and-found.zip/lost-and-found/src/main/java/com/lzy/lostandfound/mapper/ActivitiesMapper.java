package com.lzy.lostandfound.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.lzy.lostandfound.entity.Activities;

/**
 * <p>
 * 用户活动日志表 Mapper 接口
 * </p>
 *
 * @author baomidou
 * @since 2025-11-05
 */
public interface ActivitiesMapper extends BaseMapper<Activities> {

}
