package com.lzy.lostandfound.service.impl;

import com.lzy.lostandfound.entity.Activities;
import com.lzy.lostandfound.mapper.ActivitiesMapper;
import com.lzy.lostandfound.service.IActivitiesService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 用户活动日志表 服务实现类
 * </p>
 *
 * @author baomidou
 * @since 2025-11-05
 */
@Service
public class ActivitiesServiceImpl extends ServiceImpl<ActivitiesMapper, Activities> implements IActivitiesService {

}
