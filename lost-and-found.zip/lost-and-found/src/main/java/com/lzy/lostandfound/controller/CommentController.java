package com.lzy.lostandfound.controller;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.lzy.lostandfound.entity.Comment;
import com.lzy.lostandfound.entity.CommentLike;
import com.lzy.lostandfound.service.ICommentLikeService;
import com.lzy.lostandfound.service.ICommentService;
import com.lzy.lostandfound.service.IUserService;
import com.lzy.lostandfound.utils.ThreadLocalUtil;
import com.lzy.lostandfound.vo.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.*;

/**
 * 评论接口
 * @author lzy
 * @since 2025-10-16
 */
@CrossOrigin(origins = "http://localhost:5174")
@RestController
@RequestMapping("/comments")
public class CommentController {

    @Autowired
    private ICommentService commentService;

    @Autowired
    private ICommentLikeService commentLikeService;
    @Autowired
    private IUserService userService;

    /**
     * 添加评论
     */
    @PostMapping("/add")
    public Result addComment(@RequestBody Comment comment) {
        Map<String, Object> userMap = ThreadLocalUtil.get();
        String userId = (String) userMap.get("id");

        // 参数校验
        if (comment.getInfoId() == null ||
                comment.getInfoType() == null ||
                (!"lost".equals(comment.getInfoType()) && !"find".equals(comment.getInfoType()))) {
            return Result.error("参数错误");
        }

        comment.setId(UUID.randomUUID().toString());
        comment.setUserId(userId);
        comment.setLikeCount(0);
        comment.setCreateTime(LocalDateTime.now());
        comment.setUsername((String) userMap.get("username"));
        comment.setAvatar( userService.getById(userId).getAvatar());

        boolean saved = commentService.save(comment);
        return saved ? Result.success("评论成功") : Result.error("评论失败");
    }

    /**
     * 获取评论列表（分页）
     */
    @GetMapping("/list")
    public Result getComments(@RequestParam String infoId,
                              @RequestParam String infoType,
                              @RequestParam(defaultValue = "1") Integer page,
                              @RequestParam(defaultValue = "20") Integer pageSize) {

        if (!"lost".equals(infoType) && !"find".equals(infoType)) {
            return Result.error("信息类型错误");
        }

        //
        Page<Comment> pageInfo = new Page<>(page, pageSize);

        LambdaQueryWrapper<Comment> queryWrapper = new LambdaQueryWrapper<Comment>()
                .eq(Comment::getInfoId, infoId)
                .eq(Comment::getInfoType, infoType)
                .orderByDesc(Comment::getCreateTime);

        commentService.page(pageInfo, queryWrapper);

        Map<String, Object> data = new HashMap<>();
        data.put("list", pageInfo.getRecords());
        data.put("total", pageInfo.getTotal());

        return Result.success(data);
    }

    /**
     * 删除评论（仅作者可删）
     */
    @DeleteMapping("delete/{id}")
    public Result deleteComment(@PathVariable String id) {
        Map<String, Object> userMap = ThreadLocalUtil.get();
        String userId = (String) userMap.get("id");

        Comment comment = commentService.getById(id);
        if (comment == null) {
            return Result.error("评论不存在");
        }

        if (!(comment.getUserId().equals(userId)||userService.getById(userId).getRole().equals("ADMIN"))) {
            return Result.forbidden("无权限删除此评论");
        }

        boolean removed = commentService.removeById(id);
        return removed ? Result.success("删除成功") : Result.error("删除失败");
    }

    /**
     * 点赞 / 取消点赞
     */
    @PostMapping("/like/{id}")
    public Result toggleLike(@PathVariable String id) {
        Map<String, Object> userMap = ThreadLocalUtil.get();
        String userId = (String) userMap.get("id");

        Comment comment = commentService.getById(id);
        if (comment == null) {
            return Result.error("评论不存在");
        }

        LambdaQueryWrapper<CommentLike> wrapper = new LambdaQueryWrapper<CommentLike>()
                .eq(CommentLike::getCommentId, id)
                .eq(CommentLike::getUserId, userId);

        CommentLike exist = commentLikeService.getOne(wrapper, false);

        if (exist != null) {
            // 取消点赞
            commentLikeService.remove(wrapper);
            comment.setLikeCount(Math.max(0, comment.getLikeCount() - 1));
            commentService.updateById(comment);
            return Result.success("取消点赞成功");
        } else {
            // 新增点赞
            CommentLike like = new CommentLike();
            like.setId(UUID.randomUUID().toString());
            like.setCommentId(id);
            like.setUserId(userId);
            like.setCreateTime(LocalDateTime.now());
            commentLikeService.save(like);

            comment.setLikeCount(comment.getLikeCount() + 1);
            commentService.updateById(comment);
            return Result.success("点赞成功");
        }
    }



}
