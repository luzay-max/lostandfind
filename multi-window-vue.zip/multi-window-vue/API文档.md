# 前端API接口文档

## 项目介绍

本项目是一个基于Vue 3和Element Plus的失物招领系统前端，通过以下API模块与后端进行交互：

- 用户认证模块 (authApi)
- 用户信息模块 (userApi)
- 失物信息模块 (lostApi)
- 招领信息模块 (findApi)
- 评论模块 (commentsApi)
- 审核模块 (auditApi)
- 聊天消息模块 (chatApi)

## API使用说明

### 统一导入方式

```javascript
// 方式1：导入整个API对象
import api from '@/api';

// 使用示例
api.login({ username: 'admin', password: '123456' });

// 方式2：按需导入特定API函数
import { login, getUserInfo } from '@/api';

// 使用示例
login({ username: 'admin', password: '123456' });
getUserInfo();
```

### 认证机制

- 登录成功后，token会自动保存到localStorage
- 每次请求时，会自动从localStorage获取token并添加到请求头
- 当token过期或无效时，会自动跳转到登录页面

### 响应格式

统一的响应格式：

```javascript
{
  code: 0, // 状态码，0表示成功，非0表示失败
  message: '成功', // 响应消息
  data: {} // 响应数据
}
```

## API测试工具

本项目内置了API测试工具，可以在开发环境下方便地测试各个接口：

### 使用方法

1. 打开浏览器控制台 (F12)
2. 在控制台中运行以下命令：

```javascript
// 测试认证相关接口（登录、获取用户信息等）
apiTests.testAuthApis();

// 测试失物信息相关接口
apiTests.testLostApis();

// 测试招领信息相关接口
apiTests.testFindApis();

// 运行所有测试
apiTests.runAllTests();
```

### 测试配置

测试账号信息在 `src/utils/apiTestUtil.js` 中定义，可以根据实际情况修改：

```javascript
// 基础配置
const TEST_USERNAME = 'test_user';
const TEST_PASSWORD = '123456';
```

## 接口列表

### 认证模块 (authApi)

- `login(data)` - 用户登录
- `register(data)` - 用户注册  
- `logout()` - 用户登出
- `getUserInfo()` - 获取用户信息
- `updateUserInfo(data)` - 更新用户信息
- `resetPassword(data)` - 重置密码
- `sendCode(email)` - 发送验证码
- `verifyEmail(data)` - 验证邮箱

### 用户信息模块 (userApi)

- `login(data)` - 用户登录
- `register(data)` - 用户注册
- `getUserInfo()` - 获取用户信息
- `updateUserInfo(data)` - 更新用户信息
- `updateAvatar(data)` - 更新用户头像

### 失物信息模块 (lostApi)

- `publishLost(data)` - 发布失物信息
- `getLostList(params)` - 获取失物信息列表
- `searchLost(params)` - 搜索失物信息
- `getLostDetail(id)` - 获取失物信息详情
- `updateLostStatus(data)` - 更新失物信息状态
- `getUserLostList(params)` - 获取用户发布的失物信息
- `getHotLostList()` - 获取热门失物列表

### 招领信息模块 (findApi)

- `publishFind(data)` - 发布招领信息
- `getFindList(params)` - 获取招领信息列表
- `searchFind(params)` - 搜索招领信息
- `getFindDetail(id)` - 获取招领信息详情
- `updateFindStatus(data)` - 更新招领信息状态
- `getUserFindList(params)` - 获取用户发布的招领信息

### 评论模块 (commentsApi)

- `addComment(data)` - 添加评论
- `getComments(params)` - 获取评论列表
- `likeComment(id)` - 点赞评论
- `deleteComment(id)` - 删除评论

### 审核模块 (auditApi)

- `getAuditList(params)` - 获取待审核信息列表
- `auditPass(data)` - 审核通过
- `auditApprove(data)` - 审核通过（别名）
- `batchAuditApprove(data)` - 批量审核通过
- `auditReject(data)` - 审核驳回
- `getAuditHistory(params)` - 获取审核历史记录
- `getAuditStats()` - 获取审核统计数据

### 聊天消息模块 (chatApi)

- `leaveMessage(data)` - 留言
- `replyMessage(data)` - 回复留言
- `getMessageList(params)` - 获取留言列表
- `deleteMessage(id)` - 删除留言
- `getNotifications(params)` - 获取用户收到的消息通知
- `markAsRead(id)` - 标记消息已读