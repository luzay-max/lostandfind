<template>
  <div class="audit-page">
    <PageContainer title="信息审核">
      <AuditList @view-detail="handleViewDetail" />
    </PageContainer>
  </div>
</template>

<script>
import { useRouter } from 'vue-router';
import AuditList from '../../components/audit/AuditList.vue';
import PageContainer from '../../components/common/PageContainer.vue';

export default {
  name: 'AuditPage',
  components: {
    AuditList,
    PageContainer
  },
  setup() {
    const router = useRouter();
    
    // 处理查看详情
    const handleViewDetail = ({ id, type }) => {
      router.push({
        name: 'InfoDetailPage',
        params: { id, type }
      });
    };
    
    return {
      handleViewDetail
    };
  }
};
</script>

<style scoped>
.audit-page {
  width: 100%;
}

/* 响应式设计 */
@media (max-width: 768px) {
  .audit-page {
    padding: 0 10px;
  }
}
</style>