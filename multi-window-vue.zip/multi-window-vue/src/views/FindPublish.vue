<template>
  <div class="find-publish-page">
    <PageContainer title="发布招领信息">
      <FindForm @publish-success="handlePublishSuccess" />
    </PageContainer>
  </div>
</template>

<script>
import { useRouter } from 'vue-router';
import { useInfoStore } from '../store/infoStore';
import { ElMessage } from 'element-plus';
import FindForm from '../components/lostFind/FindForm.vue';
import PageContainer from '../components/common/PageContainer.vue';

export default {
  name: 'FindPublish',
  components: {
    FindForm,
    PageContainer
  },
  setup() {
    const router = useRouter();
    const infoStore = useInfoStore();
    
    // 处理发布成功
    const handlePublishSuccess = async (data) => {
      ElMessage.success('发布成功！信息将在审核通过后显示');
      await infoStore.fetchActivities();
      // 跳转到信息详情页
      router.push({
        name: 'InfoDetailPage',
        params: { id: data.id, type: 'find' }
      });
    };
    
    return {
      handlePublishSuccess
    };
  }
};
</script>

<style scoped>
.find-publish-page {
  width: 100%;
  padding: 20px;
}

/* 响应式设计 */
@media (max-width: 768px) {
  .find-publish-page {
    padding: 15px;
  }
}

@media (max-width: 480px) {
  .find-publish-page {
    padding: 10px;
  }
}
</style>