<template>
  <div class="lost-list-page">
    <PageContainer title="失物信息">
      <InfoList 
        infoType="lost"
        :initial-filters="{ keyword }"
        :show-admin-features="userStore.isAdmin"
        @view-detail="handleViewDetail"
      />
    </PageContainer>
  </div>
</template>

<script>
import { useRouter, useRoute } from 'vue-router';
import InfoList from '../components/lostFind/InfoList.vue';
import PageContainer from '../components/common/PageContainer.vue';
import { useUserStore } from '../store/userStore';

export default {
  name: 'LostList',
  components: {
    InfoList,
    PageContainer
  },
  setup() {
    const router = useRouter();
    const route = useRoute();
    const userStore = useUserStore();
    const keyword = route.query.keyword;

    
    // 处理查看详情
    const handleViewDetail = ({ id, type }) => {
      router.push({
        name: 'InfoDetailPage',
        params: { id, type }
      });
    };
    
    return {
      handleViewDetail,
      keyword,
      userStore
    };
  }
};
</script>

<style scoped>
.lost-list-page {
  width: 100%;
  padding: 20px;
}

/* 响应式设计 */
@media (max-width: 768px) {
  .lost-list-page {
    padding: 15px;
  }
}

@media (max-width: 480px) {
  .lost-list-page {
    padding: 10px;
  }
}
</style>