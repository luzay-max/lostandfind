<template>
  <div class="register-page">
    <div class="register-container">
      <div class="register-header">
        <h2>用户注册</h2>
        <p>欢迎加入校园失物招领平台</p>
      </div>
      
      <RegisterForm
        @register-success="handleRegisterSuccess"
        @to-login="handleToLogin"
      />
      
      <div class="register-footer">
        <p>注册即表示您同意<a href="#" class="link">用户协议</a>和<a href="#" class="link">隐私政策</a></p>
      </div>
    </div>
  </div>
</template>

<script>
import { useRouter } from 'vue-router';
import { ElMessage } from 'element-plus';
import RegisterForm from '../components/user/RegisterForm.vue';

export default {
  name: 'Register',
  components: {
    RegisterForm
  },
  setup() {
    const router = useRouter();
    
    // 处理注册成功
    const handleRegisterSuccess = () => {
      // 注册成功后跳转到登录页面
      ElMessage.success('注册成功，请登录');
      router.push('/login');
    };
    
    // 跳转到登录页面
    const handleToLogin = () => {
      router.push('/login');
    };
    
    return {
      handleRegisterSuccess,
      handleToLogin
    };
  }
};
</script>

<style scoped>
.register-page {
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  background-color: #f5f7fa;
  background-image: 
    radial-gradient(#e8eaed 1px, transparent 0),
    radial-gradient(#e8eaed 1px, transparent 0);
  background-size: 40px 40px;
  background-position: 0 0, 20px 20px;
}

.register-container {
  background-color: white;
  border-radius: 12px;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
  padding: 40px;
  width: 100%;
  max-width: 550px;
  transition: all 0.3s ease;
}

.register-header {
  text-align: center;
  margin-bottom: 30px;
}

.register-header h2 {
  font-size: 28px;
  color: var(--text-primary);
  margin-bottom: 10px;
  font-weight: 600;
}

.register-header p {
  color: var(--text-secondary);
  font-size: 16px;
}

.register-footer {
  text-align: center;
  margin-top: 20px;
  font-size: 14px;
  color: var(--text-secondary);
}

.link {
  color: var(--primary-color);
  text-decoration: none;
  transition: color 0.3s;
}

.link:hover {
  color: var(--primary-dark);
  text-decoration: underline;
}

/* 响应式设计 */
@media (max-width: 768px) {
  .register-container {
    margin: 0 20px;
    padding: 30px;
    box-shadow: 0 5px 20px rgba(0, 0, 0, 0.1);
  }
  
  .register-header h2 {
    font-size: 24px;
  }
  
  .register-header p {
    font-size: 14px;
  }
}

@media (max-width: 480px) {
  .register-container {
    margin: 0 15px;
    padding: 25px;
  }
  
  .register-header {
    margin-bottom: 25px;
  }
  
  .register-header h2 {
    font-size: 22px;
  }
}
</style>