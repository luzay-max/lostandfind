<template>
  <div class="home">
    <!-- 首页轮播 -->
    <div class="banner">
      <div class="banner-content">
        <h1>校园失物招领平台</h1>
        <p>寻找失物，归还物品，共建和谐校园</p>
        <div class="search-box">
          <el-input
            v-model="searchKeyword"
            placeholder="搜索物品名称或描述"
            prefix-icon="Search"
            @keyup.enter="handleSearch"
          >
            <template #append>
              <el-button type="primary" @click="handleSearch">搜索</el-button>
            </template>
          </el-input>
        </div>
        <div class="quick-actions">
          <el-button type="primary" size="large" @click="navigateTo('lostPublish')">发布失物</el-button>
          <el-button size="large" @click="navigateTo('findPublish')">发布招领</el-button>
        </div>
      </div>
    </div>

    <!-- 统计卡片 -->
    <div class="stats-container">
      <el-row :gutter="20">
        <el-col :span="8">
          <el-card class="stat-card">
            <div class="stat-content">
              <div class="stat-icon lost-icon"></div>
              <div class="stat-info">
                <div class="stat-number">{{ stats.lostCount }}</div>
                <div class="stat-label">失物信息</div>
              </div>
            </div>
          </el-card>
        </el-col>
        <el-col :span="8">
          <el-card class="stat-card">
            <div class="stat-content">
              <div class="stat-icon find-icon"></div>
              <div class="stat-info">
                <div class="stat-number">{{ stats.findCount }}</div>
                <div class="stat-label">招领信息</div>
              </div>
            </div>
          </el-card>
        </el-col>
        <el-col :span="8">
          <el-card class="stat-card">
            <div class="stat-content">
              <div class="stat-icon solved-icon"></div>
              <div class="stat-info">
                <div class="stat-number">{{ stats.solvedCount }}</div>
                <div class="stat-label">已解决</div>
              </div>
            </div>
          </el-card>
        </el-col>
      </el-row>

      <!-- 管理员统计卡片 -->
      <el-row :gutter="20" v-if="userStore.isAdmin">
        <el-col :span="8">
          <el-card class="stat-card admin-card">
            <div class="stat-content">
              <div class="stat-icon pending-icon"></div>
              <div class="stat-info">
                <div class="stat-number">{{ stats.pendingCount }}</div>
                <div class="stat-label">待审核信息</div>
              </div>
            </div>
          </el-card>
        </el-col>
        <el-col :span="8">
          <el-card class="stat-card admin-card">
            <div class="stat-content">
              <div class="stat-icon user-icon"></div>
              <div class="stat-info">
                <div class="stat-number">{{ stats.userCount }}</div>
                <div class="stat-label">总用户数</div>
              </div>
            </div>
          </el-card>
        </el-col>
        <el-col :span="8">
          <el-card class="stat-card admin-card">
            <div class="stat-content">
              <div class="stat-icon reject-icon"></div>
              <div class="stat-info">
                <div class="stat-number">{{ stats.rejectCount }}</div>
                <div class="stat-label">已拒绝</div>
              </div>
            </div>
          </el-card>
        </el-col>
      </el-row>
    </div>

    <!-- 热门信息 -->
    <div class="hot-section">
      <div class="section-header">
        <h2>热门信息</h2>
        <div class="tab-buttons">
          <el-button 
            type="text" 
            :class="{ active: activeTab === 'lost' }" 
            @click="activeTab = 'lost'"
          >
            失物
          </el-button>
          <el-button 
            type="text" 
            :class="{ active: activeTab === 'find' }" 
            @click="activeTab = 'find'"
          >
            招领
          </el-button>
        </div>
      </div>
      
      <div class="hot-list">
        <div v-if="loading" class="loading">
          <el-skeleton :rows="6" animated></el-skeleton>
        </div>
        <div v-else-if="hotItems.length === 0" class="empty">
          暂无相关信息
        </div>
        <div v-else class="hot-items">
          <el-card 
            v-for="item in hotItems" 
            :key="item.id" 
            class="hot-item"
            @click="viewDetail(item.id, activeTab)"
          >
            <div class="hot-item-content">
              <div class="item-info">
                <h3 class="item-name">{{ item.name }}</h3>
                <p class="item-desc">{{ item.description }}</p>
                <div class="item-meta">
                  <span class="item-location">{{ item.location }}</span>
                  <span class="item-time">{{ formatDate(item.publishTime) }}</span>
                </div>
              </div>
              <div class="item-image">
                <img v-if="item.images && item.images.length > 0" :src="item.images[0]" :alt="item.name">
                <div v-else class="no-image">暂无图片</div>
              </div>
            </div>
          </el-card>
        </div>
      </div>
      
      <div class="section-footer">
        <el-button 
          type="text" 
          @click="navigateTo(activeTab === 'lost' ? 'lostList' : 'findList')"
        >
          查看更多 <el-icon><Right /></el-icon>
        </el-button>
      </div>
    </div>

    <!-- 最近动态 -->
    <div class="activity-section">
      <div class="section-header">
        <h2>最近动态</h2>
      </div>
      
      <div class="activity-list">
        <div v-if="activities.length === 0" class="empty">
          暂无动态
        </div>
        <div v-else class="activities">
          <div v-for="(activity, index) in activities" :key="index" class="activity-item">
            <div class="activity-icon">
              <el-icon v-if="activity.type === 'lost'">
                <Document /></el-icon>
              <el-icon v-else>
                <Bell /></el-icon>
            </div>
            <div class="activity-content">
              <p>
                <span class="activity-user">{{ activity.userName }}</span>
                <span class="activity-item-name">{{ activity.itemName }}</span>
              </p>
              <span class="activity-time">{{ formatRelativeTime(activity.time) }}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { ref, reactive, onMounted, watch } from 'vue';
import { ElMessage } from 'element-plus';
import { useRouter } from 'vue-router';
import { Right, Document, Bell } from '@element-plus/icons-vue';
import { getHotLostList, getHotFindList, getStatistics, getRecentActivities } from '../api';
import { useUserStore } from '../store/userStore';
const userStore = useUserStore();
export default {
  name: 'Home',
  components: {
    Right,
    Document,
    Bell
  },
  setup() {
    const router = useRouter();
    const loading = ref(false);
    const activeTab = ref('lost');
    const searchKeyword = ref('');
    
    // 统计数据
    const stats = reactive({
      lostCount: 0,
      findCount: 0,
      solvedCount: 0,
      pendingCount: 0,
      userCount: 0,
      rejectCount:0
    });
    
    // 热门信息
    const hotItems = ref([]);
    
    // 最近动态
    const activities = ref([]);
    
    // 加载最近动态
    const loadRecentActivities = async () => {
      try {
        // 调用API获取最近动态，限制10条数据
        const response = await getRecentActivities({ limit: 10 });
        
        // 如果后端返回了数据，则使用后端数据
        if (response.data && Array.isArray(response.data)) {
          activities.value = response.data;
        } else {
          // 如果没有数据，使用模拟数据作为降级方案
          activities.value = [
            { userName: '张三', action: '发布了失物信息', itemName: '校园卡', type: 'lost', time: Date.now() - 3600000 },
            { userName: '李四', action: '发布了招领信息', itemName: '钱包', type: 'find', time: Date.now() - 7200000 },
            { userName: '王五', action: '找回了物品', itemName: '手机', type: 'lost', time: Date.now() - 86400000 },
            { userName: '赵六', action: '认领了物品', itemName: '钥匙', type: 'find', time: Date.now() - 172800000 }
          ];
        }
      } catch (error) {
        // 发生错误时，使用模拟数据作为降级方案
        console.error('获取最近动态失败:', error);
        activities.value = [
          { userName: '张三', action: '发布了失物信息', itemName: '校园卡', type: 'lost', time: Date.now() - 3600000 },
          { userName: '李四', action: '发布了招领信息', itemName: '钱包', type: 'find', time: Date.now() - 7200000 },
          { userName: '王五', action: '找回了物品', itemName: '手机', type: 'lost', time: Date.now() - 86400000 },
          { userName: '赵六', action: '认领了物品', itemName: '钥匙', type: 'find', time: Date.now() - 172800000 }
        ];
      }
    };
    
    // 格式化日期
    const formatDate = (timestamp) => {
      if (!timestamp) return '';
      const date = new Date(timestamp);
      return `${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')} ${String(date.getHours()).padStart(2, '0')}:${String(date.getMinutes()).padStart(2, '0')}`;
    };
    
    // 格式化相对时间
    const formatRelativeTime = (timestamp) => {
      if (!timestamp) return '';
      const now = Date.now();
      const diff = now - timestamp;
      
      if (diff < 60000) {
        return '刚刚';
      } else if (diff < 3600000) {
        return `${Math.floor(diff / 60000)}分钟前`;
      } else if (diff < 86400000) {
        return `${Math.floor(diff / 3600000)}小时前`;
      } else if (diff < 604800000) {
        return `${Math.floor(diff / 86400000)}天前`;
      } else {
        return formatDate(timestamp);
      }
    };
    
    // 加载统计数据
    const loadStatistics = async () => {
  try {
    const response = await getStatistics();
    const statsData = response.data || {};
    Object.assign(stats, {
      lostCount: statsData.lostCount || 0,
      findCount: statsData.findCount || 0,
      solvedCount: statsData.solvedCount || 0,
      rejectCount: statsData.rejectCount || 0,
      pendingCount: statsData.pendingCount || 0,
      userCount: statsData.userCount || 0
    });
  } catch (error) {
    // 在模拟环境中使用默认数据
    Object.assign(stats, {
      lostCount: 128,
      findCount: 96,
      solvedCount: 85,
      rejectCount: 15,
      pendingCount: 9,
      userCount: 8
    });
    // 不显示错误日志，避免影响用户体验
  }
};
    
    // 加载热门信息
   // 加载热门信息
const loadHotItems = async () => {
  try {
    loading.value = true;
    let res;
    if (activeTab.value === 'lost') {
      res = await getHotLostList();
    } else {
      res = await getHotFindList();
    }

    // ✅ 数据适配：解析 images 字段，确保它是数组
    const list = (res.data || []).map(item => {
      let parsedImages = [];
      try {
        // 如果是字符串形式的 JSON 数组，解析它
        if (typeof item.images === 'string') {
          parsedImages = JSON.parse(item.images);
        } else if (Array.isArray(item.images)) {
          parsedImages = item.images;
        }
      } catch (e) {
        parsedImages = [];
      }
      return {
        ...item,
        images: parsedImages
      };
    });

    hotItems.value = list;
  } catch (error) {
    // 模拟环境默认数据
    hotItems.value =
      activeTab.value === 'lost'
        ? [
            {
              id: '1',
              name: '校园卡',
              description: '在图书馆二楼丢失的校园卡，姓名：张三',
              location: '图书馆',
              publishTime: Date.now() - 3600000,
              images: []
            },
            {
              id: '2',
              name: '钱包',
              description: '在食堂一楼丢失的黑色钱包',
              location: '第一食堂',
              publishTime: Date.now() - 7200000,
              images: []
            },
            {
              id: '3',
              name: '手机',
              description: '在教室丢失的白色手机',
              location: '教学楼A栋302',
              publishTime: Date.now() - 10800000,
              images: []
            }
          ]
        : [
            {
              id: '1',
              name: '钥匙串',
              description: '在操场捡到的钥匙串',
              location: '体育场',
              publishTime: Date.now() - 1800000,
              images: []
            },
            {
              id: '2',
              name: '笔记本电脑',
              description: '在自习室捡到的笔记本电脑',
              location: '自习室C区',
              publishTime: Date.now() - 5400000,
              images: []
            },
            {
              id: '3',
              name: '眼镜',
              description: '在教室捡到的近视眼镜',
              location: '教学楼B栋201',
              publishTime: Date.now() - 9000000,
              images: []
            }
          ];
  } finally {
    loading.value = false;
  }
};

    
    // 搜索
    const handleSearch = () => {
      if (!searchKeyword.value.trim()) {
        ElMessage.warning('请输入搜索关键词');
        return;
      }
      
      // 跳转到失物列表页并带上搜索参数
      router.push({
        name: 'LostList',
        query: { keyword: searchKeyword.value }
      });
    };
    
    // 查看详情
    const viewDetail = (id, type) => {
      router.push({
        name: 'InfoDetailPage',
        params: { id, type }
      });
    };
    
    // 导航到指定页面
    const navigateTo = (routeName) => {
      // 处理路由名称大小写，确保与路由配置一致
      let formattedRouteName = routeName;
      // 如果是首页的发布按钮，修正路由名称（首字母大写）
      if (routeName === 'lostPublish') formattedRouteName = 'LostPublish';
      if (routeName === 'findPublish') formattedRouteName = 'FindPublish';
      if (routeName === 'lostList') formattedRouteName = 'LostList';
      if (routeName === 'findList') formattedRouteName = 'FindList';
      
      router.push({ name: formattedRouteName });
    };
    
    // 监听标签变化
    watch(activeTab, () => {
      loadHotItems();
    });
    
    // 组件挂载时加载数据
    onMounted(() => {
      loadStatistics();
      loadHotItems();
      loadRecentActivities();
    });
    
    return {
      loading,
      activeTab,
      searchKeyword,
      stats,
      hotItems,
      activities,
      formatDate,
      formatRelativeTime,
      handleSearch,
      viewDetail,
      navigateTo,
      userStore
    };
  }
};
</script>

<style scoped>
.home {
  width: 100%;
}

/* 轮播样式 */
.banner {
  background: linear-gradient(135deg, var(--primary-color) 0%, var(--primary-dark) 100%);
  color: white;
  padding: 60px 0;
  text-align: center;
  margin-bottom: 30px;
}

.banner-content {
  max-width: 800px;
  margin: 0 auto;
}

.banner h1 {
  font-size: 36px;
  margin-bottom: 16px;
  font-weight: 600;
}

.banner p {
  font-size: 18px;
  margin-bottom: 30px;
  opacity: 0.9;
}

.search-box {
  max-width: 600px;
  margin: 0 auto 30px;
}

.quick-actions {
  display: flex;
  justify-content: center;
  gap: 20px;
}

/* 统计卡片样式 */
.stats-container {
  margin-bottom: 30px;
}

.stat-card {
  transition: transform 0.3s, box-shadow 0.3s;
}

.stat-card:hover {
  transform: translateY(-5px);
  box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
}

.stat-content {
  display: flex;
  align-items: center;
  gap: 20px;
}

.stat-icon {
  width: 60px;
  height: 60px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
}

.lost-icon {
  background-color: rgba(245, 108, 108, 0.1);
   background-image: url('../assets/icons/lost.png');
   background-repeat: no-repeat;
  background-size: 30px;
  background-position: center;
}

.find-icon {
  background-color: rgba(255, 255, 255, 0.1);
   background-image: url('../assets/icons/find.png');
   background-repeat: no-repeat;
  background-size: 40px;
  background-position: center;
}

.stat-icon.solved-icon {
  background-color: rgba(58, 194, 188, 0.1);
  background-image: url('../assets/icons/solved.png');
  background-repeat: no-repeat;
  background-size: contain;
  background-size: 30px;
  background-position: center;
}

.stat-icon.pending-icon {
  background-color: rgba(255, 125, 0, 0.1);
  background-image: url('../assets/icons/pending.png');
  background-repeat: no-repeat;
  background-size: 30px;
  background-position: center;
}

.stat-icon.user-icon {
  background-color: rgba(0, 180, 42, 0.1);
  background-image: url('../assets/icons/user.png');
  background-repeat: no-repeat;
  background-size: 30px;
  background-position: center;
}
.stat-icon.reject-icon {
  background-color: rgba(0, 180, 42, 0.1);
  background-image: url('../assets/icons/reject.png');
  background-repeat: no-repeat;
  background-size: 30px;
  background-position: center;
}

.admin-card {
  border-left: 4px solid #1890ff;
}

.stat-number {
  font-size: 28px;
  font-weight: 600;
  color: var(--text-primary);
}

.stat-label {
  font-size: 14px;
  color: var(--text-secondary);
}

/* 热门信息样式 */
.hot-section,
.activity-section {
  margin-bottom: 40px;
}

.section-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
}

.section-header h2 {
  font-size: 24px;
  font-weight: 600;
  color: var(--text-primary);
}

.tab-buttons .el-button {
  margin-left: 20px;
  padding: 8px 16px;
  min-width: 80px;
  text-align: center;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.tab-buttons .el-button.active {
  color: var(--primary-color);
  font-weight: 500;
}

.hot-item {
  margin-bottom: 15px;
  cursor: pointer;
  transition: transform 0.2s;
}

.hot-item:hover {
  transform: translateX(5px);
}

.hot-item-content {
  display: flex;
  gap: 20px;
}

.item-info {
  flex: 1;
}

.item-name {
  font-size: 18px;
  margin-bottom: 8px;
  color: var(--text-primary);
}

.item-desc {
  font-size: 14px;
  color: var(--text-secondary);
  margin-bottom: 10px;
  overflow: hidden;
  text-overflow: ellipsis;
  display: -webkit-box;
  line-clamp: 2;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
}

.item-meta {
  font-size: 12px;
  color: var(--text-secondary);
  display: flex;
  gap: 20px;
}

.item-image {
  width: 120px;
  height: 90px;
  overflow: hidden;
  border-radius: 4px;
  background-color: #f5f7fa;
}

.item-image img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.no-image {
  width: 100%;
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  color: var(--text-secondary);
  font-size: 12px;
}

.section-footer {
  text-align: right;
  margin-top: 15px;
}

.empty {
  text-align: center;
  padding: 40px 0;
  color: var(--text-secondary);
}

/* 最近动态样式 */
.activity-item {
  display: flex;
  align-items: flex-start;
  gap: 15px;
  padding: 15px 0;
  border-bottom: 1px solid #f0f0f0;
}

.activity-item:last-child {
  border-bottom: none;
}

.activity-icon {
  width: 40px;
  height: 40px;
  border-radius: 50%;
  background-color: var(--primary-light);
  display: flex;
  align-items: center;
  justify-content: center;
  color: var(--primary-color);
  flex-shrink: 0;
}

.activity-content p {
  margin-bottom: 5px;
  line-height: 1.6;
}

.activity-user {
  font-weight: 500;
  color: var(--text-primary);
}

.activity-action {
  color: var(--text-secondary);
}

.activity-item-name {
  color: var(--primary-color);
  font-weight: 500;
}

.activity-time {
  font-size: 12px;
  color: var(--text-secondary);
}

/* 响应式设计 */
@media (max-width: 768px) {
  .banner {
    padding: 40px 0;
  }
  
  .banner h1 {
    font-size: 28px;
  }
  
  .banner p {
    font-size: 16px;
  }
  
  .search-box {
    max-width: 100%;
    margin: 0 20px 20px;
  }
  
  .quick-actions {
    flex-direction: column;
    align-items: center;
    gap: 10px;
  }
  
  .stat-content {
    flex-direction: column;
    text-align: center;
    gap: 10px;
  }
  
  .section-header {
    flex-direction: column;
    align-items: flex-start;
    gap: 10px;
  }
  
  .hot-item-content {
    flex-direction: column;
  }
  
  .item-image {
    width: 100%;
    height: 180px;
  }
}

@media (max-width: 480px) {
  .banner {
    padding: 30px 0;
  }
  
  .banner h1 {
    font-size: 24px;
  }
  
  .stat-number {
    font-size: 24px;
  }
}
</style>
