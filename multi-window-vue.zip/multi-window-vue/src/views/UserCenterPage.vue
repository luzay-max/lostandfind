<template>
  <div class="user-center-page">
    <PageContainer title="个人中心">
      <UserCenter @view-detail="handleViewDetail" />
    </PageContainer>
  </div>
</template>

<script>
import { useRouter } from 'vue-router';
import UserCenter from '../components/user/UserCenter.vue';
import PageContainer from '../components/common/PageContainer.vue';

export default {
  name: 'UserCenterPage',
  components: {
    UserCenter,
    PageContainer
  },
  setup() {
    const router = useRouter();
    
    // 处理查看详情
    const handleViewDetail = ({ id, type }) => {
      router.push({
        name: 'InfoDetailPage',
        params: { id, type }
      });
    };
    
    return {
      handleViewDetail
    };
  }
};
</script>

<style scoped>
.user-center-page {
  width: 100%;
  padding: 20px;
}

/* 响应式设计 */
@media (max-width: 768px) {
  .user-center-page {
    padding: 15px;
  }
}

@media (max-width: 480px) {
  .user-center-page {
    padding: 10px;
  }
}
</style>