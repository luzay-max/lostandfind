<template>
  <div class="info-detail-page">
    <PageContainer title="信息详情">
      <InfoDetail 
        :infoId="id" 
        :infoType="type"
        @back="handleBack"
      />
      <CommentSection
        :infoId="id"
        :infoType="type"
      />
    </PageContainer>
  </div>
</template>

<script>
import { ref, onMounted } from 'vue';
import { useRoute, useRouter } from 'vue-router';
import InfoDetail from '../components/lostFind/InfoDetail.vue';
import CommentSection from '../components/lostFind/CommentSection.vue';
import PageContainer from '../components/common/PageContainer.vue';

export default {
  name: 'InfoDetailPage',
  components: {
    InfoDetail,
    CommentSection,
    PageContainer
  },
  setup() {
    const route = useRoute();
    const router = useRouter();
    const id = ref('');
    const type = ref('lost');
    
    // 处理返回
    const handleBack = () => {
      router.back();
    };
    
    // 直接获取路由参数（无需等待mounted）
    id.value = route.params.id;
    type.value = route.params.type || 'lost';
    
    return {
      id,
      type,
      handleBack
    };
  }
};
</script>

<style scoped>
.info-detail-page {
  width: 100%;
  padding: 20px;
}

/* 响应式设计 */
@media (max-width: 768px) {
  .info-detail-page {
    padding: 15px;
  }
}

@media (max-width: 480px) {
  .info-detail-page {
    padding: 10px;
  }
}
</style>