<template>
  <div class="lost-publish-page">
    <PageContainer title="发布失物信息">
      <LostForm @publish-success="handlePublishSuccess" />
    </PageContainer>
  </div>
</template>

<script>
import { useRouter } from 'vue-router';
import { useInfoStore } from '../store/infoStore';
import { ElMessage } from 'element-plus';
import LostForm from '../components/lostFind/LostForm.vue';
import PageContainer from '../components/common/PageContainer.vue';

export default {
  name: 'LostPublish',
  components: {
    LostForm,
    PageContainer
  },
  setup() {
    const router = useRouter();
    const infoStore = useInfoStore();
    
    // 处理发布成功
    const handlePublishSuccess = async (data) => {
      ElMessage.success('发布成功！信息将在审核通过后显示');
      await infoStore.fetchActivities();
      // 跳转到信息详情页
      router.push({
        name: 'InfoDetailPage',
        params: { id: data.id, type: 'lost' }
      });
    };
    
    return {
      handlePublishSuccess
    };
  }
};
</script>

<style scoped>
.lost-publish-page {
  width: 100%;
  padding: 20px;
}

/* 响应式设计 */
@media (max-width: 768px) {
  .lost-publish-page {
    padding: 15px;
  }
}

@media (max-width: 480px) {
  .lost-publish-page {
    padding: 10px;
  }
}
</style>