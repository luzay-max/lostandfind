<template>
  <div class="find-list-page">
    <PageContainer title="招领信息">
      <InfoList 
        infoType="find"
        :show-admin-features="userStore.isAdmin"
        @view-detail="handleViewDetail"
      />
    </PageContainer>
  </div>
</template>

<script>
import { useRouter } from 'vue-router';
import InfoList from '../components/lostFind/InfoList.vue';
import PageContainer from '../components/common/PageContainer.vue';
import { useUserStore } from '../store/userStore';

export default {
  name: 'FindList',
  components: {
    InfoList,
    PageContainer
  },
  setup() {
    const router = useRouter();
    const userStore = useUserStore();
    
    // 处理查看详情
    const handleViewDetail = ({ id, type }) => {
      router.push({
        name: 'InfoDetailPage',
        params: { id, type }
      });
    };
    
    return {
      handleViewDetail,
      userStore
    };
  }
};
</script>

<style scoped>
.find-list-page {
  width: 100%;
  padding: 20px;
}

/* 响应式设计 */
@media (max-width: 768px) {
  .find-list-page {
    padding: 15px;
  }
}

@media (max-width: 480px) {
  .find-list-page {
    padding: 10px;
  }
}
</style>