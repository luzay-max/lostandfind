import { createRouter, createWebHistory } from 'vue-router';
import { useUserStore } from '../store/userStore';
import { ElMessage } from 'element-plus';

// 导入页面组件
const Home = () => import('../views/Home.vue');
const Login = () => import('../views/Login.vue');
const Register = () => import('../views/Register.vue');
const UserCenterPage = () => import('../views/UserCenterPage.vue');
const LostPublish = () => import('../views/LostPublish.vue');
const FindPublish = () => import('../views/FindPublish.vue');
const LostList = () => import('../views/LostList.vue');
const FindList = () => import('../views/FindList.vue');
const InfoDetailPage = () => import('../views/InfoDetailPage.vue');

// 管理员页面组件
// 已移除管理中心页面
const AuditPage = () => import('../views/Admin/AuditPage.vue');

const routes = [
  {
    path: '/',
    name: 'Home',
    component: Home,
    meta: {
      title: '首页 - 校园失物招领平台',
      requiresAuth: false
    }
  },
  {
    path: '/login',
    name: 'Login',
    component: Login,
    meta: {
      title: '登录 - 校园失物招领平台',
      requiresAuth: false,
      guest: true
    }
  },
  {
    path: '/register',
    name: 'Register',
    component: Register,
    meta: {
      title: '注册 - 校园失物招领平台',
      requiresAuth: false,
      guest: true
    }
  },
  {
    path: '/user-center',
    name: 'UserCenterPage',
    component: UserCenterPage,
    meta: {
      title: '个人中心 - 校园失物招领平台',
      requiresAuth: true
    }
  },
  {
    path: '/lost/publish',
    name: 'LostPublish',
    component: LostPublish,
    meta: {
      title: '发布失物 - 校园失物招领平台',
      requiresAuth: true
    }
  },
  {
    path: '/find/publish',
    name: 'FindPublish',
    component: FindPublish,
    meta: {
      title: '发布招领 - 校园失物招领平台',
      requiresAuth: true
    }
  },
  {
    path: '/lost/list',
    name: 'LostList',
    component: LostList,
    meta: {
      title: '失物列表 - 校园失物招领平台',
      requiresAuth: false
    }
  },
  {
    path: '/find/list',
    name: 'FindList',
    component: FindList,
    meta: {
      title: '招领列表 - 校园失物招领平台',
      requiresAuth: false
    }
  },
  {
    path: '/info/detail/:type/:id',
    name: 'InfoDetailPage',
    component: InfoDetailPage,
    meta: {
      title: '信息详情 - 校园失物招领平台',
      requiresAuth: false
    },
    props: true
  },
  // 管理员路由
  {
    path: '/admin/audit',
    name: 'AuditPage',
    component: AuditPage,
    meta: {
      title: '信息审核 - 校园失物招领平台',
      requiresAuth: true,
      requiresAdmin: true
    }
  },
  // 404页面
  {
    path: '/:pathMatch(.*)*',
    name: 'NotFound',
    redirect: '/',
    meta: {
      title: '页面不存在 - 校园失物招领平台',
      requiresAuth: false
    }
  }
];

const router = createRouter({
  history: createWebHistory(),
  routes
});

// 全局前置守卫
router.beforeEach(async (to, from, next) => {
  // 设置页面标题
  document.title = to.meta.title || '校园失物招领平台';
  
  const userStore = useUserStore();
  
  // 检查是否需要登录
  if (to.meta.requiresAuth && !userStore.isLoggedIn) {
    ElMessage.warning('请先登录');
    return next({
      path: '/login',
      query: { redirect: to.fullPath }
    });
  }
  
  // 检查是否需要管理员权限
  if (to.meta.requiresAdmin && !userStore.isAdmin) {
    ElMessage.error('没有权限访问该页面');
    return next('/');
  }
  
  // 已登录用户不能访问登录和注册页面
  if (to.meta.guest && userStore.isLoggedIn) {
    return next('/');
  }
  
  next();
});

export default router;