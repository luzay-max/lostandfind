<template>
  <div class="image-upload">
    <el-upload
      class="upload-demo"
      :action="uploadAction"
      :multiple="multiple"
      :file-list="fileList"
      :on-preview="handlePreview"
      :on-remove="handleRemove"
      :before-upload="beforeUpload"
      :http-request="customUpload"
      :auto-upload="true"
      list-type="picture-card"
      :limit="maxCount"
      :on-exceed="handleExceed"
      :disabled="disabled"
    >
      <template #default>
        <el-icon class="el-icon--plus"><Plus /></el-icon>
        <div class="el-upload__text">
          {{ multiple ? '点击或拖拽上传图片\n最多上传' + maxCount + '张' : '点击或拖拽上传图片' }}
        </div>
      </template>
      <template #tip>
        <div class="el-upload__tip">
          请上传jpg、jpeg、png、gif格式图片，单张图片大小不超过5MB
        </div>
      </template>
    </el-upload>

    <!-- 图片预览对话框 -->
    <el-dialog v-model="dialogVisible" title="图片预览" width="80%">
      <img :src="dialogImageUrl" alt="预览图片" class="preview-image">
    </el-dialog>
  </div>
</template>

<script>
import { ref, computed } from 'vue';
import { ElMessage } from 'element-plus';
import { Plus } from '@element-plus/icons-vue';
import { uploadFileToOss, isImageFile, validateFileSize, formatFileSize } from '../../utils/ossUtil';

export default {
  name: 'ImageUpload',
  components: {
    Plus
  },
  props: {
    // 是否支持多图上传
    multiple: {
      type: Boolean,
      default: false
    },
    // 最大上传数量
    maxCount: {
      type: Number,
      default: 9
    },
    // 已上传的图片列表
    modelValue: {
      type: [String, Array],
      default: ''
    },
    // 上传类型（avatar或image）
    uploadType: {
      type: String,
      default: 'image'
    },
    // 是否禁用
    disabled: {
      type: Boolean,
      default: false
    }
  },
  emits: ['update:modelValue', 'change', 'error'],
  setup(props, { emit }) {
    const fileList = ref([]);
    const dialogVisible = ref(false);
    const dialogImageUrl = ref('');
    
    // 计算上传动作（由于使用阿里云OSS，这里设置为一个假的action）
    const uploadAction = computed(() => '/#');
    
    // 初始化文件列表
    const initFileList = () => {
      if (props.modelValue) {
        if (Array.isArray(props.modelValue)) {
          fileList.value = props.modelValue.map(url => ({
            name: url.substring(url.lastIndexOf('/') + 1),
            url
          }));
        } else {
          fileList.value = [{
            name: props.modelValue.substring(props.modelValue.lastIndexOf('/') + 1),
            url: props.modelValue
          }];
        }
      }
    };
    
    // 组件挂载时初始化
    initFileList();
    
    // 预览图片
    const handlePreview = (file) => {
      dialogImageUrl.value = file.url;
      dialogVisible.value = true;
    };
    
    // 删除图片
    const handleRemove = (file, fileList) => {
      const urls = fileList.map(item => item.url);
      updateModelValue(urls);
    };
    
    // 自定义上传函数
    const customUpload = async (options) => {
      try {
        const file = options.file;
        
        // 检查文件类型
        if (!isImageFile(file)) {
          ElMessage.error('请上传jpg、jpeg、png、gif格式的图片');
          options.onError(new Error('文件类型错误'));
          return false;
        }
        
        // 检查文件大小
        if (!validateFileSize(file, 5)) {
          ElMessage.error(`文件大小不能超过5MB，当前文件大小：${formatFileSize(file.size)}`);
          options.onError(new Error('文件大小超出限制'));
          return false;
        }
        
        // 使用阿里云OSS上传
        options.onProgress({ percent: 50 }); // 模拟进度
        const url = await uploadFileToOss(file, props.uploadType);
        
        // 更新文件URL
        const fileObj = fileList.value.find(f => f.uid === file.uid);
        if (fileObj) {
          fileObj.url = url;
        }
        
        // 更新值
        const urls = fileList.value.map(item => item.url).filter(url => url);
        updateModelValue(urls);
        
        options.onSuccess({ url }); // 调用成功回调
        ElMessage.success('图片上传成功');
      } catch (error) {
        console.error('图片上传失败:', error);
        ElMessage.error('图片上传失败：' + (error.message || '未知错误'));
        options.onError(error); // 调用失败回调
        emit('error', error);
      }
    };
    
    // 上传前检查（由于使用自定义上传，这个函数主要用于控制是否允许选择文件）
    const beforeUpload = (file) => {
      // 检查文件类型
      if (!isImageFile(file)) {
        ElMessage.error('请上传jpg、jpeg、png、gif格式的图片');
        return false;
      }
      
      // 检查文件大小
      if (!validateFileSize(file, 5)) {
        ElMessage.error(`文件大小不能超过5MB，当前文件大小：${formatFileSize(file.size)}`);
        return false;
      }
      
      return true;
    };
    
    // 文件超出数量限制
    const handleExceed = (files, fileList) => {
      ElMessage.warning(`最多只能上传${props.maxCount}张图片`);
    };
    
    // 更新模型值
    const updateModelValue = (urls) => {
      if (props.multiple) {
        emit('update:modelValue', urls);
        emit('change', urls);
      } else {
        emit('update:modelValue', urls[0] || '');
        emit('change', urls[0] || '');
      }
    };
    
    return {
      fileList,
      dialogVisible,
      dialogImageUrl,
      uploadAction,
      handlePreview,
      handleRemove,
      beforeUpload,
      customUpload,
      handleExceed
    };
  },
  // 监听props变化
  watch: {
    modelValue: {
      handler() {
        initFileList();
      },
      deep: true
    }
  }
};
</script>

<style scoped>
.image-upload {
  margin-bottom: 20px;
}

.upload-demo {
  display: flex;
  flex-wrap: wrap;
  gap: 16px;
}

.el-upload__text {
  font-size: 12px !important;
  line-height: 1.5 !important;
}

.preview-image {
  width: 100%;
  max-height: 600px;
  object-fit: contain;
}

/* 响应式设计 */
@media (max-width: 768px) {
  .upload-demo {
    gap: 12px;
  }
  
  .preview-image {
    max-height: 400px;
  }
}

@media (max-width: 480px) {
  .upload-demo {
    gap: 8px;
  }
  
  .preview-image {
    max-height: 300px;
  }
}
</style>