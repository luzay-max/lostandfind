<template>
  <footer class="footer">
    <div class="container">
      <div class="footer-content">
        <div class="footer-info">
          <h3 class="footer-title">校园失物招领平台</h3>
          <p class="footer-description">
            本平台致力于为宁波财经学院的师生提供便捷的失物招领服务，
            帮助大家快速找回丢失的物品，传递校园正能量。
          </p>
        </div>
        
        <div class="footer-links">
          <h4 class="link-title">快速链接</h4>
          <ul class="link-list">
            <li><router-link to="/lost/list">失物信息</router-link></li>
            <li><router-link to="/find/list">招领信息</router-link></li>
            <li><router-link to="/">使用帮助</router-link></li>
            <li><router-link to="/">联系我们</router-link></li>
          </ul>
        </div>
        
        <div class="footer-contact">
          <h4 class="contact-title">联系我们</h4>
          <p class="contact-item">
            <i class="el-icon-location"></i>
            <span>宁波财经学院数字技术与工程学院</span>
          </p>
          <p class="contact-item">
            <i class="el-icon-phone"></i>
            <span>0574-XXXXXXX</span>
          </p>
          <p class="contact-item">
            <i class="el-icon-message"></i>
            <span>service@example.com</span>
          </p>
        </div>
      </div>
      
      <div class="footer-bottom">
        <p class="copyright">
          © 2024 宁波财经学院数字技术与工程学院 22计科软开1班李志阳. All Rights Reserved.
        </p>
      </div>
    </div>
  </footer>
</template>

<script>
export default {
  name: 'Footer'
};
</script>

<style scoped>
.footer {
  background-color: #303133;
  color: #ffffff;
  padding: 40px 0 20px;
  margin-top: auto;
}

.container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 20px;
}

.footer-content {
  display: flex;
  justify-content: space-between;
  margin-bottom: 30px;
  flex-wrap: wrap;
}

.footer-info,
.footer-links,
.footer-contact {
  flex: 1;
  min-width: 250px;
  margin-bottom: 20px;
}

.footer-title {
  font-size: 20px;
  font-weight: 600;
  margin-bottom: 16px;
  color: var(--primary-color);
}

.footer-description {
  font-size: 14px;
  line-height: 1.6;
  color: #909399;
}

.link-title,
.contact-title {
  font-size: 16px;
  font-weight: 500;
  margin-bottom: 16px;
  color: #ffffff;
}

.link-list {
  list-style: none;
}

.link-list li {
  margin-bottom: 10px;
}

.link-list a {
  color: #909399;
  text-decoration: none;
  transition: color 0.3s;
  display: block;
  padding: 5px 0;
}

.link-list a:hover {
  color: var(--primary-color);
  transform: translateX(5px);
}

.contact-item {
  display: flex;
  align-items: center;
  margin-bottom: 12px;
  color: #909399;
  font-size: 14px;
}

.contact-item i {
  margin-right: 10px;
  color: var(--primary-color);
}

.footer-bottom {
  border-top: 1px solid #4E4E50;
  padding-top: 20px;
  text-align: center;
}

.copyright {
  font-size: 12px;
  color: #6B6B6E;
  margin: 0;
}

/* 响应式设计 */
@media (max-width: 768px) {
  .footer-content {
    flex-direction: column;
  }
  
  .footer-info,
  .footer-links,
  .footer-contact {
    min-width: 100%;
    margin-bottom: 30px;
  }
  
  .contact-item {
    font-size: 13px;
  }
  
  .footer-bottom {
    padding-top: 15px;
  }
  
  .copyright {
    font-size: 11px;
    line-height: 1.5;
  }
}

@media (max-width: 480px) {
  .footer {
    padding: 30px 0 15px;
  }
  
  .footer-title {
    font-size: 18px;
  }
  
  .link-title,
  .contact-title {
    font-size: 15px;
  }
  
  .footer-description {
    font-size: 13px;
  }
}
</style>