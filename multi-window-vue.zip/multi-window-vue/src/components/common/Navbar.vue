<template>
  <el-header class="navbar">
    <div class="navbar-container">
      <!-- Logo -->
      <div class="logo" @click="navigateTo('home')">
        <el-icon><Compass /></el-icon>
        <span>校园失物招领</span>
      </div>

  <!-- 主导航 -->
  <el-menu
    :default-active="activeIndex"
    class="main-menu"
    mode="horizontal"
    :ellipsis="false"
    @select="handleMenuSelect"
  >
    <el-menu-item index="home">{{ userStore.isAdmin ? '管理员中心' : '首页' }}</el-menu-item>
    <el-menu-item index="lostList">失物信息</el-menu-item>
    <el-menu-item index="findList">招领信息</el-menu-item>
  </el-menu>
  
  <!-- 用户操作区 -->
  <div class="user-actions">
    <div v-if="!userStore.isLoggedIn" class="login-register">
      <el-button 
        :class="{ 'text-primary': activeIndex === 'login' }"
        type="text" 
        @click="navigateTo('login')"
      >
        登录
      </el-button>
      <el-button 
        :class="{ 'is-active': activeIndex === 'register' }"
        type="primary" 
        @click="navigateTo('register')"
      >
        注册
      </el-button>
    </div>
    
    <div v-else class="user-menu">
      <template v-if="!userStore.isAdmin">
        <el-button type="primary" class="publish-btn" @click="showPublishMenu = !showPublishMenu">
          <el-icon><Plus /></el-icon> 发布
        </el-button>
        <div class="publish-dropdown" v-if="showPublishMenu">
          <div class="dropdown-item" @click="navigateTo('lostPublish')">
            <el-icon><Document /></el-icon> 发布失物
          </div>
          <div class="dropdown-item" @click="navigateTo('findPublish')">
            <el-icon><Bell /></el-icon> 发布招领
          </div>
        </div>
        
        <el-dropdown @command="handleUserCommand">
          <div class="user-info" @click="(e) => { e.stopPropagation(); navigateTo('userCenter'); }">
            <el-avatar :size="36" :src="userStore.userInfo.avatar || defaultAvatar" />
            <span class="user-name">{{ userStore.userInfo.username || '用户' }}</span>
            <el-icon class="arrow-icon"><ArrowDown /></el-icon>
          </div>
          <template #dropdown>
            <el-dropdown-menu>
              <el-dropdown-item command="userCenter">个人中心</el-dropdown-item>
              <el-dropdown-item command="logout">退出登录</el-dropdown-item>
            </el-dropdown-menu>
          </template>
        </el-dropdown>
      </template>
      
      <template v-else>
        <el-menu
          :default-active="activeAdminIndex"
          class="admin-menu"
          mode="horizontal"
          @select="handleAdminMenuSelect"
        >
          <el-menu-item index="audit">信息审核</el-menu-item>
        </el-menu>
        
        <el-dropdown @command="handleUserCommand">
          <div class="user-info" @click="(e) => { e.stopPropagation(); navigateTo('userCenter'); }">
            <el-avatar :size="36" :src="userStore.userInfo.avatar || defaultAvatar" />
            <span class="user-name">{{ userStore.userInfo.username || '管理员' }}(管理员)</span>
            <el-icon class="arrow-icon"><ArrowDown /></el-icon>
          </div>
          <template #dropdown>
            <el-dropdown-menu>
              <el-dropdown-item command="logout">退出登录</el-dropdown-item>
            </el-dropdown-menu>
          </template>
        </el-dropdown>
      </template>
    </div>
  </div>
</div>

  </el-header>
</template>

<script>
import { ref, computed, onMounted, onUnmounted } from 'vue';
import { useRouter, useRoute } from 'vue-router';
import { ElMessage, ElMessageBox } from 'element-plus';
import { Compass, Plus, Document, Bell, ArrowDown } from '@element-plus/icons-vue';
import { useUserStore } from '../../store/userStore';
import { logout } from '../../api/authApi';

export default {
  name: 'Navbar',
  components: { Compass, Plus, Document, Bell, ArrowDown },
  setup() {
    const router = useRouter();
    const route = useRoute();
    const userStore = useUserStore();
    const showPublishMenu = ref(false);
    const defaultAvatar = '/src/assets/images/1.png';
    
    const activeIndex = computed(() => {
      const path = route.path;
      if (path === '/') return 'home';
      if (path.startsWith('/lost/list')) return 'lostList';
      if (path.startsWith('/find/list')) return 'findList';
      if (path === '/login') return 'login';
      if (path === '/register') return 'register';
      return 'home';
    });
    
    const activeAdminIndex = computed(() => route.path.startsWith('/admin/audit') ? 'audit' : 'audit');
    
    const handleMenuSelect = (index) => navigateTo(index);
    const handleAdminMenuSelect = (index) => navigateTo(index);
    
    const handleUserCommand = async (command) => {
      if (command === 'userCenter') navigateTo('userCenter');
      else if (command === 'logout') handleLogout();
    };
    
    const handleLogout = () => {
      ElMessageBox.confirm('确定要退出登录吗？', '提示', { confirmButtonText: '确定', cancelButtonText: '取消', type: 'warning' })
        .then(async () => {
          try { await logout(); } catch(e) { console.error(e); }
          finally { userStore.logout(); ElMessage.success('退出登录成功'); window.location.href = '/'; }
        }).catch(() => {});
    };
    
    const navigateTo = (routeName) => {
      const routeMap = {
        'audit': '/admin/audit',
        'userCenter': '/user-center',
        'lostList': '/lost/list',
        'findList': '/find/list',
        'lostPublish': '/lost/publish',
        'findPublish': '/find/publish',
        'login': '/login',
        'register': '/register',
        'home': '/'
      };
      router.push(routeMap[routeName] || routeName);
    };
    
    const handleClickOutside = (event) => {
      const navbar = document.querySelector('.navbar');
      if (navbar && !navbar.contains(event.target)) showPublishMenu.value = false;
    };
    
    onMounted(() => document.addEventListener('click', handleClickOutside));
    onUnmounted(() => document.removeEventListener('click', handleClickOutside));
    
    return { userStore, showPublishMenu, activeIndex, activeAdminIndex, defaultAvatar, handleMenuSelect, handleAdminMenuSelect, handleUserCommand, handleLogout, navigateTo };
  }
};
</script>

<style scoped>
.navbar { background-color: #fff; box-shadow: 0 2px 4px rgba(0,0,0,0.08); height: 60px; position: sticky; top: 0; z-index: 1000; }
.navbar-container { display: flex; align-items: center; justify-content: space-between; height: 100%; max-width: 1400px; margin: 0 auto; padding: 0 20px; }
.logo { display: flex; align-items: center; font-size: 20px; font-weight: 600; color: var(--primary-color); cursor: pointer; gap: 8px; }
.logo .el-icon { font-size: 24px; }
.main-menu { flex: 1; justify-content: center; background-color: transparent; }
.main-menu .el-menu-item { font-size: 16px; color: var(--text-primary); min-width: 80px; transition: color 0.3s; }
.main-menu .el-menu-item.is-active { color: var(--primary-color); font-weight: 500; }
.user-actions { display: flex; align-items: center; gap: 15px; }
.login-register { display: flex; gap: 10px; }
.login-register .text-primary { color: var(--primary-color); font-weight: 500; }
.login-register .el-button.is-active { background-color: var(--primary-dark,#337ecc); border-color: var(--primary-dark,#337ecc); }
.user-menu { display: flex; align-items: center; gap: 15px; }
.publish-btn { display: flex; align-items: center; gap: 5px; }
.publish-dropdown { position: absolute; top: 60px; right: 180px; background-color: #fff; border-radius: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.15); padding: 10px 0; z-index: 1001; min-width: 160px; }
.dropdown-item { display: flex; align-items: center; gap: 8px; padding: 10px 20px; cursor: pointer; transition: background-color 0.3s; }
.dropdown-item:hover { background-color: var(--background-color); }
.user-info { display: flex; align-items: center; gap: 8px; cursor: pointer; padding: 5px 10px; border-radius: 20px; transition: background-color 0.3s; }
.user-info:hover { background-color: var(--background-color); }
.user-name { font-size: 14px; color: var(--text-primary); max-width: 100px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.arrow-icon { font-size: 12px; color: var(--text-secondary); }
.admin-menu { background-color: transparent; }
.admin-menu .el-menu-item { font-size: 14px; color: var(--text-primary); min-width: 80px; }
.admin-menu .el-menu-item.is-active { color: var(--primary-color); font-weight: 500; }
.el-menu--horizontal > .el-submenu .el-submenu__title { border-bottom: 2px solid transparent; transition: all 0.3s ease; }
.el-menu--horizontal > .el-submenu.is-active .el-submenu__title { border-bottom-color: #409EFF; }
.el-dropdown, .el-menu, .el-button { transition: all 0.2s ease-in-out; }

/* 响应式优化 */
@media (max-width: 1024px) { .main-menu .el-menu-item { font-size: 14px; } .user-name { display: none; } }
@media (max-width: 768px) { .navbar-container { flex-direction: column; padding: 10px 15px; gap: 15px; } .main-menu { width: 100%; justify-content: space-around; } .user-actions { width: 100%; justify-content: center; } .publish-dropdown { top: auto; right: 20px; bottom: 100px; } }
@media (max-width: 480px) { .logo { font-size: 16px; } .logo .el-icon { font-size: 20px; } .main-menu .el-menu-item { font-size: 12px; padding: 0 10px; } }
</style>
