<template>
  <div class="page-container">
    <!-- 页面头部 -->
    <div v-if="title || showHeader" class="page-header">
      <h1 class="page-title">{{ title }}</h1>
      <p v-if="subtitle" class="page-subtitle">{{ subtitle }}</p>
      <slot name="header-extra"></slot>
    </div>
    
    <!-- 页面内容区 -->
    <div class="page-content">
      <slot></slot>
    </div>
    
    <!-- 页面底部 -->
    <div v-if="showFooter" class="page-footer">
      <slot name="footer"></slot>
    </div>
  </div>
</template>

<script>
export default {
  name: 'PageContainer',
  props: {
    // 页面标题
    title: {
      type: String,
      default: ''
    },
    // 页面副标题
    subtitle: {
      type: String,
      default: ''
    },
    // 是否显示头部
    showHeader: {
      type: Boolean,
      default: true
    },
    // 是否显示底部
    showFooter: {
      type: Boolean,
      default: false
    },
    // 内容区域是否使用卡片样式
    useCard: {
      type: Boolean,
      default: true
    },
    // 是否居中内容
    centerContent: {
      type: Boolean,
      default: false
    },
    // 最大宽度
    maxWidth: {
      type: String,
      default: '1200px'
    }
  },
  setup(props) {
    return {
      props
    };
  }
};
</script>

<style scoped>
.page-container {
  width: 100%;
  margin: 0 auto;
  padding: 20px 0;
  transition: all 0.3s;
}

.page-header {
  margin-bottom: 24px;
  padding: 0 20px;
}

.page-title {
  font-size: 24px;
  font-weight: 600;
  color: var(--text-primary);
  margin-bottom: 8px;
}

.page-subtitle {
  font-size: 14px;
  color: var(--text-secondary);
  margin: 0;
}

.page-content {
  width: 100%;
  padding: 0 20px;
}

.page-content:deep(.card) {
  background-color: var(--white);
  border-radius: 8px;
  box-shadow: var(--box-shadow);
  padding: 24px;
  margin-bottom: 0;
}

.page-footer {
  margin-top: 24px;
  padding: 0 20px;
  text-align: center;
  color: var(--text-secondary);
  font-size: 12px;
}

/* 响应式设计 */
@media (max-width: 768px) {
  .page-container {
    padding: 16px 0;
  }
  
  .page-header {
    margin-bottom: 20px;
    padding: 0 15px;
  }
  
  .page-title {
    font-size: 20px;
  }
  
  .page-content {
    padding: 0 15px;
  }
  
  .page-content:deep(.card) {
    padding: 20px;
  }
  
  .page-footer {
    padding: 0 15px;
  }
}

@media (max-width: 480px) {
  .page-container {
    padding: 12px 0;
  }
  
  .page-header {
    margin-bottom: 16px;
    padding: 0 12px;
  }
  
  .page-title {
    font-size: 18px;
  }
  
  .page-subtitle {
    font-size: 13px;
  }
  
  .page-content {
    padding: 0 12px;
  }
  
  .page-content:deep(.card) {
    padding: 16px;
  }
}
</style>