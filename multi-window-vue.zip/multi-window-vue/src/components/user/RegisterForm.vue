<template>
  <el-form ref="registerFormRef" :model="registerForm" :rules="rules" label-width="80px" class="register-form">
    <el-form-item label="用户名" prop="username">
      <el-input v-model="registerForm.username" placeholder="请输入用户名" prefix-icon="User"></el-input>
    </el-form-item>
    
    <el-form-item label="密码" prop="password">
      <el-input
        v-model="registerForm.password"
        type="password"
        placeholder="请输入密码"
        prefix-icon="Lock"
        :show-password="showPassword"
      ></el-input>
    </el-form-item>
    
    <el-form-item label="确认密码" prop="confirmPassword">
      <el-input
        v-model="registerForm.confirmPassword"
        type="password"
        placeholder="请再次输入密码"
        prefix-icon="Lock"
        :show-password="showPassword"
      ></el-input>
    </el-form-item>
    
    <el-form-item label="手机号" prop="phone">
      <el-input v-model="registerForm.phone" placeholder="请输入手机号码" prefix-icon="Phone"></el-input>
    </el-form-item>
    
    <el-form-item label="邮箱" prop="email">
      <el-input v-model="registerForm.email" placeholder="请输入邮箱地址" prefix-icon="Message"></el-input>
    </el-form-item>
    
    <el-form-item label="姓名" prop="name">
      <el-input v-model="registerForm.name" placeholder="请输入真实姓名" prefix-icon="Document"></el-input>
    </el-form-item>
    
    <el-form-item label="身份" prop="role">
      <el-select v-model="registerForm.role" placeholder="请选择身份">
        <el-option label="学生" value="STUDENT"></el-option>
        <el-option label="教职工" value="TEACHER"></el-option>
      </el-select>
    </el-form-item>
    
    <el-form-item>
      <el-button type="primary" @click="handleRegister" :loading="loading" style="width: 100%">
        注册
      </el-button>
    </el-form-item>
    
    <el-form-item>
      <el-link type="primary" :underline="false" @click="$emit('to-login')" class="login-link">
        已有账号？立即登录
      </el-link>
    </el-form-item>
  </el-form>
</template>

<script>
import { ref, reactive } from 'vue';
import { ElMessage } from 'element-plus';
import { register } from '../../api/userApi';

export default {
  name: 'RegisterForm',
  emits: ['register-success', 'to-login'],
  setup(props, { emit }) {
    const registerFormRef = ref(null);
    const loading = ref(false);
    const showPassword = ref(false);
    
    // 注册表单数据
    const registerForm = reactive({
      username: '',
      password: '',
      confirmPassword: '',
      phone: '',
      email: '',
      name: '',
      role: 'STUDENT'
    });
    
    // 表单验证规则
    const rules = {
      username: [
        { required: true, message: '请输入用户名', trigger: 'blur' },
        { min: 3, max: 20, message: '用户名长度在3-20个字符之间', trigger: 'blur' },
        { pattern: /^[a-zA-Z0-9_]+$/, message: '用户名只能包含字母、数字和下划线', trigger: 'blur' }
      ],
      password: [
        { required: true, message: '请输入密码', trigger: 'blur' },
        { min: 6, max: 20, message: '密码长度在6-20个字符之间', trigger: 'blur' },
        { pattern: /^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{6,20}$/, message: '密码必须包含字母和数字', trigger: 'blur' }
      ],
      confirmPassword: [
        { required: true, message: '请确认密码', trigger: 'blur' },
        {
          validator: (rule, value, callback) => {
            if (value !== registerForm.password) {
              callback(new Error('两次输入的密码不一致'));
            } else {
              callback();
            }
          },
          trigger: 'blur'
        }
      ],
      phone: [
        { required: true, message: '请输入手机号码', trigger: 'blur' },
        { pattern: /^1[3-9]\d{9}$/, message: '请输入正确的手机号码', trigger: 'blur' }
      ],
      email: [
        { required: true, message: '请输入邮箱地址', trigger: 'blur' },
        { pattern: /^[^\s@]+@[^\s@]+\.[^\s@]+$/, message: '请输入正确的邮箱地址', trigger: 'blur' }
      ],
      name: [
        { required: true, message: '请输入真实姓名', trigger: 'blur' },
        { min: 2, max: 20, message: '姓名长度在2-20个字符之间', trigger: 'blur' }
      ],
      role: [
        { required: true, message: '请选择身份', trigger: 'change' }
      ]
    };
    
    // 处理注册
    const handleRegister = async () => {
      if (!registerFormRef.value) return;
      
      try {
        await registerFormRef.value.validate();
        loading.value = true;
        
        // 调用注册API
        await register({
          ...registerForm
        });
        
        // 只发送注册成功事件，消息提示和跳转由父组件处理
        emit('register-success');
      } catch (error) {
        if (error !== false) { // 排除表单验证失败的情况
          ElMessage.error('注册失败：' + (error.message || '未知错误'));
        }
      } finally {
        loading.value = false;
      }
    };
    
    return {
      registerFormRef,
      loading,
      showPassword,
      registerForm,
      rules,
      handleRegister
    };
  }
};
</script>

<style scoped>
.register-form {
  max-width: 500px;
  margin: 0 auto;
  padding: 20px;
  background-color: var(--white);
  border-radius: 8px;
  box-shadow: var(--box-shadow);
}

.register-form .el-form-item {
  margin-bottom: 20px;
}

.login-link {
  display: block;
  text-align: center;
}

/* 响应式设计 */
@media (max-width: 768px) {
  .register-form {
    max-width: 100%;
    margin: 0 20px;
    padding: 16px;
  }
  
  .register-form .el-form-item {
    margin-bottom: 16px;
  }
}

@media (max-width: 480px) {
  .register-form {
    margin: 0 12px;
    padding: 12px;
  }
}
</style>