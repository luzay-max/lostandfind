<template>
  <div class="user-center">
    <!-- 个人信息展示 -->
    <el-card class="info-card">
      <template #header>
        <div class="card-header">
          <span>个人信息</span>
          <el-button 
            type="primary" 
            size="small" 
            @click="isEditing = !isEditing"
          >
            {{ isEditing ? '取消编辑' : '编辑信息' }}
          </el-button>
        </div>
      </template>
      
      <div class="user-info">
        <!-- 头像 -->
        <div class="avatar-section">
          <div class="avatar-container">
            <el-avatar :size="120" :src="userInfo.avatar || defaultAvatar" />
            <el-button
              v-if="isEditing"
              type="primary"
              size="small"
              class="change-avatar-btn"
              @click="triggerAvatarUpload"
            >
              修改头像
            </el-button>
          </div>
          <input
            ref="avatarInput"
            type="file"
            accept="image/*"
            style="display: none"
            name="avatar"
            @change="handleAvatarChange"
          >
        </div>
        
        <!-- 基本信息 -->
        <div class="basic-info">
          <el-form :model="editForm" ref="formRef" :rules="rules" label-width="80px" v-if="isEditing">
            <el-descriptions border :column="{xs: 1, sm: 2}">
              <el-descriptions-item label="用户名">
                {{ userInfo.username }} <!-- 用户名改为只读显示 -->
              </el-descriptions-item>
              <el-descriptions-item label="真实姓名">
                <el-form-item prop="name">
                  <el-input v-model="editForm.name" size="small" placeholder="请输入真实姓名"></el-input>
                </el-form-item>
              </el-descriptions-item>
              <el-descriptions-item label="身份">
                {{ getRoleLabel(userInfo.role) }}
              </el-descriptions-item>
              <el-descriptions-item label="手机号">
                <el-form-item prop="phone">
                  <el-input v-model="editForm.phone" size="small" placeholder="请输入手机号"></el-input>
                </el-form-item>
              </el-descriptions-item>
              <el-descriptions-item label="邮箱">
                <el-form-item prop="email">
                  <el-input v-model="editForm.email" size="small" placeholder="请输入邮箱"></el-input>
                </el-form-item>
              </el-descriptions-item>
              <el-descriptions-item label="注册时间">
                {{ formatDate(userInfo.createTime) }}
              </el-descriptions-item>
            </el-descriptions>
          </el-form>
          
          <!-- 非编辑模式 -->
          <el-descriptions v-else border :column="{xs: 1, sm: 2}">
            <el-descriptions-item label="用户名">
              {{ userInfo.username }}
            </el-descriptions-item>
            <el-descriptions-item label="真实姓名">
              {{ userInfo.name }}
            </el-descriptions-item>
            <el-descriptions-item label="身份">
              {{ getRoleLabel(userInfo.role) }}
            </el-descriptions-item>
            <el-descriptions-item label="手机号">
              {{ userInfo.phone }}
            </el-descriptions-item>
            <el-descriptions-item label="邮箱">
              {{ userInfo.email }}
            </el-descriptions-item>
            <el-descriptions-item label="注册时间">
              {{ formatDate(userInfo.createTime) }}
            </el-descriptions-item>
          </el-descriptions>
        </div>
      </div>
      
      <!-- 保存按钮 -->
      <div v-if="isEditing" class="action-buttons">
        <el-button type="primary" @click="handleSave" :loading="loading">保存修改</el-button>
      </div>
    </el-card>
    
    <!-- 我的发布 -->
    <el-card class="publish-card" v-if="!isEditing">
      <template #header>
        <div class="card-header">
          <span>我的发布</span>
          <div>
            <el-button type="text" @click="activeTab = 'lost'" :class="{ active: activeTab === 'lost' }">
              失物发布
            </el-button>
            <el-button type="text" @click="activeTab = 'find'" :class="{ active: activeTab === 'find' }">
              招领发布
            </el-button>
          </div>
        </div>
      </template>
      
      <!-- 失物发布列表 -->
      <div v-if="activeTab === 'lost'" class="publish-list">
        <div v-if="myLostList.length === 0" class="empty-list">
          您还没有发布过失物信息
        </div>
        <div v-else>
          <el-table :data="myLostList" style="width: 100%">
            <el-table-column prop="name" label="物品名称"></el-table-column>
            <el-table-column prop="location" label="丢失地点"></el-table-column>
            <el-table-column prop="publishTime" label="发布时间" width="180">
              <template #default="scope">
                {{ formatDate(scope.row.publishTime) }}
              </template>
            </el-table-column>
            <el-table-column prop="status" label="状态" width="100">
              <template #default="scope">
                <el-tag
                  :type="getStatusType(scope.row.status)"
                  size="small"
                >
                  {{ getStatusLabel(scope.row.status) }}
                </el-tag>
              </template>
            </el-table-column>
            <el-table-column label="操作" width="120">
              <template #default="scope">
                <el-button
                  type="text"
                  @click="viewDetail(scope.row.id, 'lost')"
                  size="small"
                >
                  查看
                </el-button>
              </template>
            </el-table-column>
          </el-table>
        </div>
      </div>
      
      <!-- 招领发布列表 -->
      <div v-if="activeTab === 'find'" class="publish-list">
        <div v-if="myFindList.length === 0" class="empty-list">
          您还没有发布过招领信息
        </div>
        <div v-else>
          <el-table :data="myFindList" style="width: 100%">
            <el-table-column prop="name" label="物品名称"></el-table-column>
            <el-table-column prop="location" label="拾取地点"></el-table-column>
            <el-table-column prop="publishTime" label="发布时间" width="180">
              <template #default="scope">
                {{ formatDate(scope.row.publishTime) }}
              </template>
            </el-table-column>
            <el-table-column prop="status" label="状态" width="100">
              <template #default="scope">
                <el-tag
                  :type="getStatusType(scope.row.status)"
                  size="small"
                >
                  {{ getStatusLabel(scope.row.status) }}
                </el-tag>
              </template>
            </el-table-column>
            <el-table-column label="操作" width="120">
              <template #default="scope">
                <el-button
                  type="text"
                  @click="viewDetail(scope.row.id, 'find')"
                  size="small"
                >
                  查看
                </el-button>
              </template>
            </el-table-column>
          </el-table>
        </div>
      </div>
    </el-card>
  </div>
</template>

<script>
import { ref, reactive, onMounted } from 'vue';
import { ElMessage, ElForm } from 'element-plus';
import { getUserInfo, updateUserInfo, updateAvatar } from '../../api/userApi';
import { getUserLostList } from '../../api/lostApi';
import { getUserFindList } from '../../api/findApi';
import { useUserStore } from '../../store/userStore';

export default {
  name: 'UserCenter',
  emits: ['view-detail'],
  setup(props, { emit }) {
    const userStore = useUserStore();
    const loading = ref(false);
    const isEditing = ref(false);
    const activeTab = ref('lost');
    const avatarInput = ref(null);
    const defaultAvatar = '/src/assets/images/1.png';
    const formRef = ref(null);
    
    // 用户信息
    const userInfo = ref({
      id: null,
      username: '',
      name: '',
      phone: '',
      email: '',
      avatar: '',
      role: '',
      createTime: null
    });
    
    // 编辑表单
    const editForm = reactive({
      name: '',
      phone: '',
      email: ''
    });
    
    // 我的发布列表
    const myLostList = ref([]);
    const myFindList = ref([]);
    
    // 获取角色标签
    const getRoleLabel = (role) => {
      const roleMap = {
        STUDENT: '学生',
        TEACHER: '教职工',
        ADMIN: '管理员'
      };
      return roleMap[role] || role;
    };
    
    // 获取状态标签
    const getStatusLabel = (status) => {
      const statusMap = {
        PENDING: '待审核',
        APPROVED: '已通过',
        REJECTED: '已拒绝',
        SOLVED: '已解决'
      };
      return statusMap[status] || status;
    };
    
    // 获取状态类型（用于标签颜色）
    const getStatusType = (status) => {
      const typeMap = {
        PENDING: 'warning',
        APPROVED: 'success',
        REJECTED: 'danger',
        SOLVED: 'info'
      };
      return typeMap[status] || 'info';
    };
    
    // 格式化日期
    const formatDate = (timestamp) => {
      if (!timestamp) return '';
      const date = new Date(timestamp);
      return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')} ${String(date.getHours()).padStart(2, '0')}:${String(date.getMinutes()).padStart(2, '0')}`;
    };
    
    // 加载用户信息
    const loadUserInfo = async () => {
      try {
        loading.value = true;
        const res = await getUserInfo();
        
        // 添加响应数据检查
        if (!res || res.code !== 0) {
          throw new Error(res?.message || '获取用户信息失败');
        }
        
        userInfo.value = res.data || {};
        
        // 同步到store - 注意：userStore没有setUserInfo方法，使用直接赋值方式更新userInfo
        Object.assign(userStore.userInfo, userInfo.value);
        // 同时更新本地存储
        import('../../utils/authUtil').then(({ setUserInfo }) => {
          setUserInfo(userInfo.value);
        });
        
        // 初始化编辑表单
        Object.assign(editForm, {
          name: userInfo.value.name || '',
          phone: userInfo.value.phone || '',
          email: userInfo.value.email || ''
        });
      } catch (error) {
        console.error('加载用户信息失败:', error);
        ElMessage.error('加载用户信息失败');
      } finally {
        loading.value = false;
      }
    };
    
    // 加载我的发布
    const loadMyPublishes = async () => {
      try {
          // 加载失物发布 - 传递分页参数
          const lostRes = await getUserLostList({ page: 1, pageSize: 10 });
          myLostList.value = lostRes.data?.list || [];
          
          // 加载招领发布 - 传递分页参数
          const findRes = await getUserFindList({ page: 1, pageSize: 10 });
          myFindList.value = findRes.data?.list || [];
      } catch (error) {
        console.error('加载发布信息失败:', error);
        ElMessage.error('加载发布信息失败');
      }
    };
    
    // 触发头像上传
    const triggerAvatarUpload = () => {
      if (avatarInput.value) {
        avatarInput.value.click();
      }
    };
    
    // 处理头像变化
    const handleAvatarChange = async (event) => {
      const file = event.target.files[0];
      if (!file) return;
      
      try {
        loading.value = true;
         const formData = new FormData();
    formData.append('avatar', file);

    console.log('FormData entries:');
    for (const [key, value] of formData.entries()) {
      console.log(key, value);
    }
        
        // 调用API更新头像
        const res = await updateAvatar(file);
        const avatarUrl = res.data;
        
        // 更新本地用户信息
        userInfo.value.avatar = avatarUrl;
        userStore.updateAvatar(avatarUrl);
        
        ElMessage.success('头像更新成功');
        
        // 清空input
        event.target.value = '';
      } catch (error) {
        ElMessage.error('头像更新失败');
      } finally {
        loading.value = false;
      }
    };
    
    // 表单校验规则
    const rules = reactive({
      name: [
        { required: true, message: '请输入真实姓名', trigger: 'blur' },
        { min: 2, max: 20, message: '姓名长度应在2到20个字符之间', trigger: 'blur' }
      ],
      phone: [
        { required: true, message: '请输入手机号', trigger: 'blur' },
        { pattern: /^1[3-9]\d{9}$/, message: '请输入正确的手机号码格式', trigger: 'blur' }
      ],
      email: [
        { required: true, message: '请输入邮箱', trigger: 'blur' },
        { 
          pattern: /^[^\s@]+@[^\s@]+\.[^\s@]+$/, 
          message: '请输入正确的邮箱格式', 
          trigger: 'blur' 
        }
      ]
    });
    
    // 保存修改
    const handleSave = async () => {
      if (!formRef.value) return;
      
      try {
        // 进行表单验证
        await formRef.value.validate();
        
        loading.value = true;
        
        // 调用API更新用户信息
        await updateUserInfo(editForm);
        
        // 更新本地用户信息
        Object.assign(userInfo.value, editForm);
        userStore.updateUserInfo(editForm);
        
        ElMessage.success('信息更新成功');
        isEditing.value = false;
      } catch (error) {
        if (error !== false) { // 表单验证失败时，error为false
          ElMessage.error('信息更新失败');
        }
        return;
      } finally {
        loading.value = false;
      }
    };
    
    // 查看详情
    const viewDetail = (id, type) => {
      emit('view-detail', { id, type });
    };
    
    // 组件挂载时加载数据
    onMounted(() => {
      loadUserInfo();
      loadMyPublishes();
    });
    
    return {
      loading,
      isEditing,
      activeTab,
      avatarInput,
      formRef,
      userInfo,
      editForm,
      rules,
      myLostList,
      myFindList,
      defaultAvatar,
      getRoleLabel,
      getStatusLabel,
      getStatusType,
      formatDate,
      triggerAvatarUpload,
      handleAvatarChange,
      handleSave,
      viewDetail
    };
  }
};
</script>

<style scoped>
.user-center {
  width: 100%;
}

.info-card,
.publish-card {
  margin-bottom: 20px;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.user-info {
  display: flex;
  flex-wrap: wrap;
  gap: 40px;
}

.avatar-section {
  flex-shrink: 0;
}

.avatar-container {
  position: relative;
  width: 120px;
  height: 120px;
}

.change-avatar-btn {
  position: absolute;
  bottom: 0;
  left: 0;
  width: 100%;
  border-radius: 0;
}

.basic-info {
  flex: 1;
  min-width: 300px;
}

.action-buttons {
  margin-top: 20px;
  text-align: right;
}

.publish-list {
  margin-top: 20px;
}

.empty-list {
  text-align: center;
  padding: 40px 0;
  color: var(--text-secondary);
}

.active {
  color: var(--primary-color) !important;
  font-weight: 500;
}

/* 响应式设计 */
@media (max-width: 768px) {
  .user-info {
    flex-direction: column;
    gap: 20px;
    align-items: center;
  }
  .basic-info {
    min-width: 100%;
  }
  .card-header {
    flex-direction: column;
    align-items: flex-start;
    gap: 10px;
  }
}
</style>