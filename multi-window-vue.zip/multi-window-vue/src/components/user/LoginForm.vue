<template>
  <el-form ref="loginFormRef" :model="loginForm" :rules="rules" label-width="80px" class="login-form">
    <el-form-item label="用户名" prop="username">
      <el-input v-model="loginForm.username" placeholder="请输入用户名" prefix-icon="User"></el-input>
    </el-form-item>
    
    <el-form-item label="密码" prop="password">
      <el-input
        v-model="loginForm.password"
        type="password"
        placeholder="请输入密码"
        prefix-icon="Lock"
        :show-password="showPassword"
        @keyup.enter="handleLogin"
      ></el-input>
    </el-form-item>
    
    <el-form-item>
      <el-checkbox v-model="loginForm.remember" label="记住我"></el-checkbox>
      <el-link type="primary" :underline="false" @click="$emit('to-register')" class="register-link">
        立即注册
      </el-link>
    </el-form-item>
    
    <el-form-item>
      <el-button type="primary" @click="handleLogin" :loading="loading" style="width: 100%">
        登录
      </el-button>
    </el-form-item>
  </el-form>
</template>

<script>
import { ref, reactive } from 'vue';
import { ElMessage } from 'element-plus';
import { login } from '../../api/userApi';
import { useUserStore } from '../../store/userStore';

export default {
  name: 'LoginForm',
  emits: ['login-success', 'to-register'],
  setup(props, { emit }) {
    const userStore = useUserStore();
    const loginFormRef = ref(null);
    const loading = ref(false);
    const showPassword = ref(false);
    
    // 登录表单数据
    const loginForm = reactive({
      username: '',
      password: '',
      remember: false
    });
    
    // 表单验证规则
    const rules = {
      username: [
        { required: true, message: '请输入用户名', trigger: 'blur' },
        { min: 3, max: 20, message: '用户名长度在3-20个字符之间', trigger: 'blur' }
      ],
      password: [
        { required: true, message: '请输入密码', trigger: 'blur' },
        { min: 6, max: 20, message: '密码长度在6-20个字符之间', trigger: 'blur' }
      ]
    };
    
    // 处理登录
    const handleLogin = async () => {
      if (!loginFormRef.value) return;
      
      try {
        await loginFormRef.value.validate();
        loading.value = true;
        
        // 使用userStore处理登录
        await userStore.login({
          username: loginForm.username,
          password: loginForm.password,
          remember: loginForm.remember
        });
        
        emit('login-success');
      } catch (error) {
        if (error !== false) { // 排除表单验证失败的情况
          ElMessage.error('登录失败：' + (error.message || '用户名或密码错误'));
        }
      } finally {
        loading.value = false;
      }
    };
    
    return {
      loginFormRef,
      loading,
      showPassword,
      loginForm,
      rules,
      handleLogin
    };
  }
};
</script>

<style scoped>
.login-form {
  max-width: 400px;
  margin: 0 auto;
  padding: 20px;
  background-color: var(--white);
  border-radius: 8px;
  box-shadow: var(--box-shadow);
}

.login-form .el-form-item {
  margin-bottom: 24px;
}

.register-link {
  float: right;
}

/* 响应式设计 */
@media (max-width: 768px) {
  .login-form {
    max-width: 100%;
    margin: 0 20px;
    padding: 16px;
  }
  
  .login-form .el-form-item {
    margin-bottom: 20px;
  }
}

@media (max-width: 480px) {
  .login-form {
    margin: 0 12px;
    padding: 12px;
  }
}
</style>