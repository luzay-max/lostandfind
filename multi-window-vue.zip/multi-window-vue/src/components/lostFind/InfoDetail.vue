<template>
  <div class="info-detail" v-loading="loading">
    <el-card shadow="never">
      <!-- 基本信息 -->
      <div class="basic-info">
        <h2>{{ infoDetail.name }}</h2>
        <el-tag :type="getStatusType(infoDetail.status)" size="small">
          {{ getStatusLabel(infoDetail.status) }}
        </el-tag>
        <p class="publish-time">发布时间：{{ formatDate(infoDetail.publishTime) }}</p>
      </div>

  <!-- 图片展示 -->
  <div class="image-gallery" v-if="filteredImages.length">
    <img
      v-for="(img, index) in filteredImages"
      :key="index"
      :src="img"
      alt="物品图片"
      class="gallery-img"
      @click="previewImage(img)"
    />
  </div>

  <!-- 详细信息 -->
  <div class="detail-content">
    <p><strong>类型：</strong>{{ getCategoryLabel(infoDetail.type) }}</p>
    <p><strong>地点：</strong>{{ infoDetail.location }}</p>
    <p><strong>时间：</strong>{{ formatDate(infoDetail.lostTime || infoDetail.findTime) }}</p>
    <p><strong>描述：</strong>{{ infoDetail.description }}</p>
    <p><strong>联系人：</strong>{{ infoDetail.contactName || '未提供' }}</p>
    <p><strong>联系电话：</strong>{{ infoDetail.contactPhone }}</p>
    <p><strong>邮箱：</strong>{{ infoDetail.contactEmail }}</p>
  </div>

  <!-- 操作按钮 -->
  <div class="action-buttons" v-if="canShowActions">
    <el-button type="primary" @click="handleContact">联系发布者</el-button>
    <el-button type="success" @click="handleUpdateStatus" v-if="canUpdateStatus">
      {{ infoType === 'lost' ? '标记已找回' : '标记已认领' }}
    </el-button>
  </div>
</el-card>

<!-- 图片预览 -->
<el-dialog v-model="dialogVisible" width="60%">
  <img :src="dialogImageUrl" class="preview-img" />
</el-dialog>


  </div>
</template>

<script>
import { ref, computed, watch } from 'vue'
import { ElMessage } from 'element-plus'
import { getLostDetail, updateLostStatus } from '../../api/lostApi'
import { getFindDetail, updateFindStatus } from '../../api/findApi'
import { useUserStore } from '../../store/userStore';
import { useInfoStore } from '../../store/infoStore';

export default {
  name: 'InfoDetail',
  props: {
    infoId: { type: Number, required: true },
    infoType: {
      type: String,
      default: 'lost',
      validator: (v) => ['lost', 'find'].includes(v)
    }
  },
  emits: ['status-change'],
  setup(props, { emit }) {
    const userStore = useUserStore();
    const infoStore = useInfoStore();
    const loading = ref(false)
    const dialogVisible = ref(false)
    const dialogImageUrl = ref('')

    const infoDetail = ref({
      id: null, name: '', type: '', location: '', lostTime: null, findTime: null,
      description: '', contactName: '', contactPhone: '', contactEmail: '',
      images: [], publishTime: null, status: '', userId: null
    })

    /** 图片字段自动解析 */
    const parseImages = (images) => {
      if (!images) return []
      if (Array.isArray(images)) return images
      try {
        const parsed = JSON.parse(images)
        return parsed.map(img => img.trim())
      } catch {
        return []
      }
    }

    const filteredImages = computed(() => parseImages(infoDetail.value.images).slice(0, 3))

    const canShowActions = computed(() => userStore.isLoggedIn && infoDetail.value.status === 'APPROVED')
    const canUpdateStatus = computed(() => canShowActions.value && userStore.userInfo.id === infoDetail.value.userId)

    function getCategoryLabel(value) {
      const map = { ID_CARD: '证件', ELECTRONIC: '电子产品', DAILY: '生活用品', PET: '宠物', OTHER: '其他' }
      return map[value] || '未知'
    }

    function getStatusLabel(status) {
      const map = { APPROVED: '已审核', PENDING: '待审核', REJECTED: '已拒绝', SOLVED: '已解决' }
      return map[status] || status
    }

    function getStatusType(status) {
      const map = { APPROVED: 'success', PENDING: 'warning', REJECTED: 'danger', SOLVED: 'info' }
      return map[status] || ''
    }

    function formatDate(ts) {
      if (!ts) return ''
      const d = new Date(ts)
      return isNaN(d.getTime()) ? ts : `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')} ${String(d.getHours()).padStart(2,'0')}:${String(d.getMinutes()).padStart(2,'0')}`
    }

    async function loadDetail() {
      loading.value = true
      try {
        const res = props.infoType === 'lost'
          ? await getLostDetail(props.infoId)
          : await getFindDetail(props.infoId)
        infoDetail.value = res.data || {}
      } finally {
        loading.value = false
      }
    }

    function previewImage(url) {
      dialogImageUrl.value = url
      dialogVisible.value = true
    }

    function handleContact() {
      ElMessage.info('请通过电话或邮箱与发布者联系')
    }

    async function handleUpdateStatus() {
      const updateFn = props.infoType === 'lost' ? updateLostStatus : updateFindStatus
      await updateFn({ id: props.infoId, status: 'SOLVED' })
      infoDetail.value.status = 'SOLVED'
      ElMessage.success('状态已更新');
      await infoStore.fetchActivities();
      emit('status-change', 'SOLVED')
    }

    watch(() => props.infoId, loadDetail, { immediate: true })

    return {
      infoDetail, filteredImages, loading, dialogVisible, dialogImageUrl,
      canShowActions, canUpdateStatus, getCategoryLabel, getStatusLabel,
      getStatusType, formatDate, previewImage, handleContact, handleUpdateStatus
    }
  }
}
</script>

<style scoped>
.info-detail { padding: 20px; }
.basic-info { display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; }
.basic-info h2 { margin: 0; font-size: 22px; }
.publish-time { color: #888; font-size: 13px; margin-top: 6px; }
.image-gallery { display: flex; flex-wrap: wrap; gap: 10px; margin: 15px 0; }
.gallery-img { width: 180px; height: 180px; object-fit: cover; border-radius: 8px; cursor: pointer; transition: transform 0.3s; }
.gallery-img:hover { transform: scale(1.05); }
.detail-content p { margin: 6px 0; line-height: 1.5; }
.action-buttons { display: flex; gap: 12px; margin-top: 20px; }
.preview-img { width: 100%; border-radius: 10px; }
</style>
