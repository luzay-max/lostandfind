<template>
  <el-card class="comment-section">
    <template #header>
      <div class="card-header">
        <span>评论区</span>
        <span class="comment-count">({{ totalComments }})</span>
      </div>
    </template>

<!-- 评论输入 -->
<div v-if="userStore.isLoggedIn" class="comment-input-wrapper">
  <div class="user-avatar">
    <img :src="userStore.userInfo.avatar || defaultAvatar" alt="用户头像" class="avatar">
  </div>
  <div class="input-content">
    <el-input
      v-model="commentContent"
      type="textarea"
      placeholder="写下你的评论..."
      :rows="3"
      maxlength="300"
      show-word-limit
    ></el-input>
    <div class="input-footer">
      <el-button type="primary" @click="submitComment" :loading="submittingComment">
        发表评论
      </el-button>
    </div>
  </div>
</div>

<!-- 未登录提示 -->
<div v-else class="login-prompt">
  <el-button type="primary" @click="handleLogin">登录后评论</el-button>
</div>

<!-- 评论列表 -->
<div class="comment-list">
  <div v-if="comments.length === 0" class="empty-comments">
    暂无评论，快来发表第一条评论吧！
  </div>
  <div v-for="(comment, index) in comments" :key="comment.id || index" class="comment-item">
    <div class="comment-header">
      <div class="comment-meta-wrapper">
        <img :src="comment.avatar || defaultAvatar" alt="用户头像" class="comment-avatar">
        <div class="comment-meta">
          <div class="comment-user">{{ comment.username || '匿名用户' }}</div>
          <div class="comment-time">{{ formatDate(comment.createTime) }}</div>
        </div>
      </div>
      <div v-if="canDeleteComment(comment)" class="comment-actions">
        <el-dropdown>
          <span class="el-dropdown-link">
            <el-icon><More /></el-icon>
          </span>
          <template #dropdown>
            <el-dropdown-menu>
              <el-dropdown-item @click="handleDeleteComment(comment.id)">
                <el-icon><Delete /></el-icon> 删除
              </el-dropdown-item>
            </el-dropdown-menu>
          </template>
        </el-dropdown>
      </div>
    </div>
    <div class="comment-content">{{ comment.content }}</div>
    <div class="comment-footer">
      <span 
        class="comment-like"
        :class="{ 'liked': isLiked(comment.id) }"
        @click="handleLikeComment(comment.id)"
      >
       <el-icon><Pointer /></el-icon>
        <span>{{ comment.likeCount || 0 }}</span>
      </span>
    </div>
  </div>
</div>

<!-- 加载更多 -->
<div v-if="comments.length > 0 && hasMore" class="load-more">
  <el-button type="text" @click="loadMoreComments" :loading="loadingMore">
    加载更多评论
  </el-button>
</div>


  </el-card>
</template>

<script>
import { ref, onMounted } from 'vue';
import { ElMessage, ElMessageBox } from 'element-plus';
import { More, Delete,Pointer } from '@element-plus/icons-vue';
import { useRouter } from 'vue-router';
import { getComments, addComment, likeComment, deleteComment } from '../../api/commentsApi';
import { useUserStore } from '../../store/userStore';

export default {
  name: 'CommentSection',
  props: {
    infoId: { type: [String, Number], required: true },
    infoType: { type: String, default: 'lost', validator: (v) => ['lost','find'].includes(v) }
  },
  setup(props) {
    const userStore = useUserStore();
    const router = useRouter();
    const comments = ref([]);
    const totalComments = ref(0);
    const commentContent = ref('');
    const submittingComment = ref(false);
    const loadingMore = ref(false);
    const page = ref(1);
    const pageSize = ref(10);
    const hasMore = ref(true);
    const likedComments = ref(new Set());
    const defaultAvatar = '/src/assets/images/1.png';

    const formatDate = (ts) => {
      if (!ts) return '';
      const d = new Date(ts);
      return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')} ${String(d.getHours()).padStart(2,'0')}:${String(d.getMinutes()).padStart(2,'0')}`;
    };

    // 只有登录用户才能删除评论；
    // 评论必须关联了 userId（避免把匿名评论误删）；
    // 评论者本人或管理员可删。
    const canDeleteComment = (comment) => {
      if (!userStore.isLoggedIn) return false;
      if (!comment.userId) return false;
      return (userStore.userInfo.id === comment.userId) || userStore.isAdmin;
    };
    const isLiked = (commentId) => likedComments.value.has(commentId);

    const loadComments = async (isLoadMore=false) => {
      try {
        if(!isLoadMore) page.value=1;
        const params = { infoId: props.infoId, infoType: props.infoType, page: page.value, pageSize: pageSize.value };
        const res = await getComments(params);
        const data = res.data?.data?.list || res.data?.list || [];
        totalComments.value = res.data?.data?.total ?? res.data?.total ?? 0;
        data.forEach(c=>{ c.username=c.username||'匿名用户'; c.avatar=c.avatar||defaultAvatar; c.userId = c.userId || null; });
        if(isLoadMore) comments.value.push(...data);
        else comments.value = data;
        hasMore.value = data.length === pageSize.value;
      } catch (err) { console.error(err); ElMessage.error('加载评论失败'); }
    };

    const loadMoreComments = async () => {
      if(loadingMore.value||!hasMore.value) return;
      loadingMore.value=true; page.value++; await loadComments(true); loadingMore.value=false;
    };

    const submitComment = async () => {
      if(!commentContent.value.trim()) { ElMessage.warning('请输入评论内容'); return; }
      try { submittingComment.value=true; await addComment({ infoId: props.infoId, infoType: props.infoType, content: commentContent.value.trim() }); 
            ElMessage.success('评论发布成功'); commentContent.value=''; loadComments(); }
      catch(e){ console.error(e); ElMessage.error('评论发布失败'); }
      finally{ submittingComment.value=false; }
    };

    const handleLikeComment = async (commentId) => {
      if(!userStore.isLoggedIn) return handleLogin();
      try {
        await likeComment(commentId);
        const c = comments.value.find(c=>c.id===commentId);
        if(c){
          if(isLiked(commentId)){ likedComments.value.delete(commentId); c.likeCount=Math.max(0,c.likeCount-1); }
          else{ likedComments.value.add(commentId); c.likeCount=(c.likeCount||0)+1; }
        }
      } catch { ElMessage.error('操作失败'); }
    };

    const handleDeleteComment = async (commentId) => {
      try {
        await ElMessageBox.confirm('确定要删除这条评论吗？', '确认删除', { confirmButtonText: '确定', cancelButtonText: '取消', type: 'warning' });
        await deleteComment(commentId);
        const idx = comments.value.findIndex(c=>c.id===commentId); if(idx>-1) comments.value.splice(idx,1); totalComments.value--;
        ElMessage.success('删除成功');
      } catch(e){ if(e!=='cancel') ElMessage.error('删除失败'); }
    };

    const handleLogin = () => router.push('/login');
    onMounted(async ()=>{
      // 确保用户信息已加载
      if (!userStore.userInfo.role) {
        try {
          await userStore.getUserInfo();
        } catch (error) {
          console.error('Failed to load user info:', error);
        }
      }
      loadComments();
    });

    return { comments, totalComments, commentContent, submittingComment, loadingMore, hasMore, userStore, defaultAvatar, formatDate, canDeleteComment, isLiked, submitComment, handleLikeComment, handleDeleteComment, handleLogin, loadMoreComments };
  }
};
</script>

<style scoped>
.comment-section { margin-top: 20px; padding: 20px; border-radius: 8px; background-color: #fff; }
.card-header { display: flex; align-items: center; font-weight: 600; font-size: 16px; margin-bottom: 20px; }
.comment-count { margin-left: 8px; color: var(--text-secondary); font-size: 14px; font-weight: normal; }
.comment-input-wrapper { display: flex; gap: 15px; margin-bottom: 30px; align-items: flex-start; }
.user-avatar .avatar { width: 48px; height: 48px; border-radius: 50%; object-fit: cover; flex-shrink:0; }
.input-content { flex:1; }
.input-footer { display:flex; justify-content:flex-end; margin-top:10px; }
.login-prompt { display:flex; justify-content:center; padding:20px; margin-bottom:20px; background-color:#f5f7fa; border-radius:4px; }
.comment-list { display:flex; flex-direction:column; gap:15px; margin-top:20px; }
.empty-comments { text-align:center; color:var(--text-secondary); padding:40px 0; font-size:14px; }
.comment-item { padding:15px 20px; border-radius:8px; border:1px solid #f0f0f0; background-color:#fafafa; }
.comment-header { display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:8px; }
.comment-meta-wrapper { display:flex; align-items:center; gap:12px; flex:1; }
.comment-avatar { width:36px; height:36px; border-radius:50%; object-fit:cover; flex-shrink:0; }
.comment-meta { display:flex; flex-direction:column; }
.comment-user { font-weight:500; color:var(--text-primary); }
.comment-time { font-size:12px; color:var(--text-secondary); }
.comment-actions { cursor:pointer; }
.comment-content { color:var(--text-secondary); line-height:1.8; word-break:break-word; margin-bottom:10px; }
.comment-footer { display:flex; gap:20px; }
.comment-like { display:flex; align-items:center; gap:4px; color:var(--text-secondary); cursor:pointer; font-size:14px; transition:color 0.3s; }
.comment-like:hover, .comment-like.liked { color:#409eff; }
.load-more { text-align:center; padding:20px 0; }

@media (max-width:768px){
  .comment-input-wrapper{ flex-direction:column; gap:10px; }
  .user-avatar{ display:none; }
  .comment-footer{ flex-wrap:wrap; }
  .comment-item{ padding:12px 15px; }
}
</style>
