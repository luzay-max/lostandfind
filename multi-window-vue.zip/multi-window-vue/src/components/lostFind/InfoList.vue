<template>
  <div class="info-list">
    <!-- 筛选和搜索区域 -->
    <div class="search-filter">
      <el-row :gutter="20">
        <el-col :span="shouldShowAdminFeatures && showFilters ? 6 : 12">
          <el-select v-model="filters.type" placeholder="物品类型" clearable>
            <el-option
              v-for="category in categories"
              :key="category.value"
              :label="category.label"
              :value="category.value"
            ></el-option>
          </el-select>
        </el-col>
        <el-col :span="6">
          <el-date-picker
            v-model="filters.dateRange"
            type="daterange"
            range-separator="至"
            start-placeholder="开始日期"
            end-placeholder="结束日期"
            value-format="x"
          ></el-date-picker>
        </el-col>
        <el-col :span="6" v-if="shouldShowAdminFeatures && showFilters">
          <el-select v-model="filters.status" placeholder="状态" clearable>
            <el-option label="待审核" value="PENDING"></el-option>
            <el-option label="已通过" value="APPROVED"></el-option>
            <el-option label="已拒绝" value="REJECTED"></el-option>
            <el-option label="已解决" value="SOLVED"></el-option>
          </el-select>
        </el-col>
        <el-col :span="6">
          <el-input
            v-model="filters.keyword"
            placeholder="搜索物品名称或描述"
            prefix-icon="Search"
          ></el-input>
          <div class="search-buttons">
            <el-button type="primary" @click="handleSearch" style="width: 48%;">搜索</el-button>
            <el-button @click="handleReset" style="width: 48%;">重置</el-button>
          </div>
        </el-col>
      </el-row>
    </div>

    <!-- 列表显示 -->
    <el-card class="card-container">
      <template #header>
        <div class="card-header">
          <span>{{ infoType === 'lost' ? '失物信息列表' : '招领信息列表' }}</span>
        </div>
      </template>
      
      <el-table
        v-loading="loading"
        :data="infoList"
        style="width: 100%"
        @row-click="handleRowClick"
      >
        <el-table-column prop="name" label="物品名称" width="200"></el-table-column>
        <el-table-column prop="type" label="物品类型" width="120">
          <template #default="scope">
            {{ getCategoryLabel(scope.row.type) }}
          </template>
        </el-table-column>
        <el-table-column prop="location" label="地点" width="180"></el-table-column>
        <el-table-column prop="description" label="描述" show-overflow-tooltip></el-table-column>
        <el-table-column prop="publishTime" label="发布时间" width="180">
          <template #default="scope">
            {{ formatDate(scope.row.publishTime) }}
          </template>
        </el-table-column>
        <el-table-column v-if="shouldShowAdminFeatures" prop="status" label="状态" width="100">
          <template #default="scope">
            <el-tag
              :type="getStatusType(scope.row.status)"
              size="small"
            >
              {{ getStatusLabel(scope.row.status) }}
            </el-tag>
          </template>
        </el-table-column>
      </el-table>

      <!-- 分页 -->
      <div class="pagination">
        <el-pagination
          v-model:current-page="pagination.currentPage"
          v-model:page-size="pagination.pageSize"
          :page-sizes="[10, 20, 50, 100]"
          layout="total, sizes, prev, pager, next, jumper"
          :total="pagination.total"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
        ></el-pagination>
      </div>
    </el-card>
  </div>
</template>

<script>
import { ref, reactive, computed, onMounted, watch } from 'vue';
import { ElMessage } from 'element-plus';
import { getLostList } from '../../api/lostApi';
import { getFindList } from '../../api/findApi';
import { useUserStore } from '../../store/userStore';

export default {
  name: 'InfoList',
  props: {
    // 信息类型：lost（失物）或 find（招领）
    infoType: {
      type: String,
      default: 'lost',
      validator: (value) => ['lost', 'find'].includes(value)
    },
    // 是否显示筛选条件
    showFilters: {
      type: Boolean,
      default: true
    },
    // 是否显示管理员相关功能（状态标签、状态筛选等）
    showAdminFeatures: {
      type: Boolean,
      default: false
    },
    // 初始筛选条件
    initialFilters: {
      type: Object,
      default: () => ({})
    }
  },
  emits: ['view-detail', 'update:filters'],
  setup(props, { emit }) {
    const loading = ref(false);
    const infoList = ref([]);
    const userStore = useUserStore();
    
    // 物品分类
    const categories = [
      { label: '证件', value: 'ID_CARD' },
      { label: '电子产品', value: 'ELECTRONICS' },
      { label: '书籍文具', value: 'BOOKS' },
      { label: '衣物', value: 'CLOTHES' },
      { label: '生活用品', value: 'DAILY_NECESSITIES' },
      { label: '其他', value: 'OTHER' }
    ];
    
    // 判断是否显示管理员功能
    // 计算属性：是否展示管理员功能
    const shouldShowAdminFeatures = computed(() => {
      // 如果父组件明确传入了 showAdminFeatures 值，则优先使用该值
      if (props.showAdminFeatures !== undefined) {
        return props.showAdminFeatures;
      }
      // 否则根据当前登录用户角色判断
      return userStore.isAdmin;
    });
    
    // 筛选条件
    const filters = reactive({
      type: '',
      dateRange: [],
      status: '',
      keyword: '',
      ...props.initialFilters
    });
    
    // 分页信息
    const pagination = reactive({
      currentPage: 1,
      pageSize: 10,
      total: 0
    });
    
    // 获取分类标签
    const getCategoryLabel = (value) => {
      const category = categories.find(cat => cat.value === value);
      return category ? category.label : value;
    };
    
    // 获取状态标签
    const getStatusLabel = (status) => {
      const statusMap = {
        PENDING: '待审核',
        APPROVED: '已通过',
        REJECTED: '已拒绝',
        SOLVED: '已解决'
      };
      return statusMap[status] || status;
    };
    
    // 获取状态类型（用于标签颜色）
    const getStatusType = (status) => {
      const typeMap = {
        PENDING: 'warning',
        APPROVED: 'success',
        REJECTED: 'danger',
        SOLVED: 'info'
      };
      return typeMap[status] || 'info';
    };
    
    // 格式化日期
    const formatDate = (timestamp) => {
      if (!timestamp) return '';
      const date = new Date(timestamp);
      return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')} ${String(date.getHours()).padStart(2, '0')}:${String(date.getMinutes()).padStart(2, '0')}`;
    };
    
    // 加载数据
    const loadData = async () => {
      try {
        loading.value = true;
        
        // 构建查询参数，只包含非空参数
        const params = {
          page: pagination.currentPage,
          pageSize: pagination.pageSize
        };
        
        // 只添加非空的筛选条件
        if (filters.type) {
          params.type = filters.type;
        }
        if (filters.keyword) {
          params.keyword = filters.keyword;
        }
        // 只有管理员或明确允许显示管理员功能时才添加状态筛选
        if (shouldShowAdminFeatures.value && filters.status) {
          params.status = filters.status;
        }
        
        // 添加日期范围

        if (filters.dateRange && filters.dateRange.length === 2) {
          params.startDate = filters.dateRange[0];
          params.endDate = filters.dateRange[1];
        }
        
        // 根据类型调用不同的API
        let res;
        if (props.infoType === 'lost') {
          res = await getLostList(params);
        } else {
          res = await getFindList(params);
        }
        
        infoList.value = res.data.list || [];
        pagination.total = res.data.total || 0;
      } catch (error) {
        ElMessage.error('加载失败：' + (error.message || '未知错误'));
      } finally {
        loading.value = false;
      }
    };
    
    // 搜索
    const handleSearch = () => {
      pagination.currentPage = 1;
      loadData();
      emit('update:filters', { ...filters });
    };
    
    // 重置
    const handleReset = () => {
      filters.type = '';
      filters.dateRange = [];
      // 只有管理员或明确允许显示管理员功能时才重置状态筛选
      if (shouldShowAdminFeatures.value) {
        filters.status = '';
      }
      filters.keyword = '';
      pagination.currentPage = 1;
      loadData();
      emit('update:filters', { ...filters });
    };
    
    // 分页大小变化
    const handleSizeChange = (size) => {
      pagination.pageSize = size;
      loadData();
    };
    
    // 当前页变化
    const handleCurrentChange = (current) => {
      pagination.currentPage = current;
      loadData();
    };
    
    // 行点击事件
    const handleRowClick = (row) => {
      emit('view-detail', { id: row.id, type: props.infoType });
    };
    
    // 监听初始筛选条件变化
    watch(
      () => props.initialFilters,
      (newFilters) => {
        Object.assign(filters, newFilters);
        loadData();
      },
      { deep: true }
    );
    
    // 组件挂载时加载数据
    onMounted(() => {
      loadData();
    });
    
    return {
      loading,
      infoList,
      categories,
      filters,
      pagination,
      shouldShowAdminFeatures,
      getCategoryLabel,
      getStatusLabel,
      getStatusType,
      formatDate,
      handleSearch,
      handleReset,
      handleSizeChange,
      handleCurrentChange,
      handleRowClick
    };
  }
};
</script>

<style scoped>
.info-list {
  width: 100%;
}

.search-filter {
  margin-bottom: 20px;
}

/* 解决组件宽度问题 */
.search-filter :deep(.el-select),
.search-filter :deep(.el-date-editor),
.search-filter :deep(.el-input) {
  width: 100%;
  max-width: 100%;
  box-sizing: border-box;
}

/* 限制物品类型框宽度 */
.search-filter .item-type-container :deep(.el-select) {
  width: 100%;
  max-width: 100%;
}

/* 确保各元素不重叠 */
.search-filter .el-col {
  margin-bottom: 15px;
}

.card-container {
  margin-bottom: 0;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.pagination {
  margin-top: 20px;
  display: flex;
  justify-content: flex-end;
}

/* 搜索按钮样式 */
.search-buttons {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-top: 10px;
  width: 100%;
  gap: 10px;
}

.search-buttons .el-button {
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

/* 响应式设计优化 */
@media (min-width: 769px) {
  .search-filter .el-col {
    margin-bottom: 0;
  }
}

@media (max-width: 768px) {
  .search-filter {
    margin-bottom: 15px;
  }
  
  .pagination {
    justify-content: center;
  }
}
</style>