<template>
  <el-form ref="lostFormRef" :model="lostForm" :rules="rules" label-width="120px">
    <el-form-item label="物品名称" prop="name">
      <el-input v-model="lostForm.name" placeholder="请输入物品名称" maxlength="50"></el-input>
    </el-form-item>
    
    <el-form-item label="物品类型" prop="type">
      <el-select v-model="lostForm.type" placeholder="请选择物品类型">
        <el-option
          v-for="category in categories"
          :key="category.value"
          :label="category.label"
          :value="category.value"
        ></el-option>
      </el-select>
    </el-form-item>
    
    <el-form-item label="丢失地点" prop="location">
      <el-input v-model="lostForm.location" placeholder="请输入详细的丢失地点" maxlength="100"></el-input>
    </el-form-item>
    
    
    <el-form-item label="物品描述" prop="description">
      <el-input
        v-model="lostForm.description"
        type="textarea"
        placeholder="请详细描述物品特征（如颜色、品牌、外观等）"
        :rows="4"
        maxlength="500"
      ></el-input>
    </el-form-item>
    
    <el-form-item label="联系人姓名" prop="contactName">
      <el-input v-model="lostForm.contactName" placeholder="请输入联系人姓名" maxlength="20"></el-input>
    </el-form-item>
    
    <el-form-item label="联系电话" prop="contactPhone">
      <el-input v-model="lostForm.contactPhone" placeholder="请输入联系电话" maxlength="11"></el-input>
    </el-form-item>
    
    <el-form-item label="联系邮箱" prop="contactEmail">
      <el-input v-model="lostForm.contactEmail" placeholder="请输入联系邮箱" maxlength="50"></el-input>
    </el-form-item>
    
    <el-form-item label="物品图片">
    <el-upload
    :headers="{ Authorization: `${token}` }"
   action="/api/user/uploadImage"
    name="file"
    list-type="picture-card"
    :on-success="handleUploadSuccess"
    :on-error="handleUploadError"
    :limit="9"
   multiple
        >
  <i class="el-icon-plus"></i>
</el-upload>
    </el-form-item>
    
    <el-form-item>
      <el-button type="primary" @click="handleSubmit" :loading="loading">发布失物信息</el-button>
      <el-button @click="handleReset">重置</el-button>
    </el-form-item>
  </el-form>
</template>

<script>
import { ref, reactive } from 'vue';
import { ElMessage } from 'element-plus';
import ImageUpload from '../common/ImageUpload.vue';
import { publishLost } from '../../api/lostApi';
import { getToken } from '../../utils/authUtil';

export default {
  name: 'LostForm',
  components: {
    ImageUpload
  },
  emits: ['submit-success'],
  setup(props, { emit }) {
    const lostFormRef = ref(null);
    const loading = ref(false);
const token = getToken();
    
    // 物品分类
    const categories = [
      { label: '证件', value: 'ID_CARD' },
      { label: '电子产品', value: 'ELECTRONICS' },
      { label: '书籍文具', value: 'BOOKS' },
      { label: '衣物', value: 'CLOTHES' },
      { label: '生活用品', value: 'DAILY_NECESSITIES' },
      { label: '其他', value: 'OTHER' }
    ];
    const handleUploadSuccess = (res) => {
  // res.data 就是返回的 OSS 图片 URL
  lostForm.images.push(res.data)
}

const handleUploadError = (err) => {
  ElMessage.error('图片上传失败')
}
    
    // 表单数据
    const lostForm = reactive({
      name: '',
      type: '',
      location: '',
      description: '',
      contactName: '',
      contactPhone: '',
      contactEmail: '',
      images: []
    });
    
    // 表单验证规则
    const rules = {
      name: [
        { required: true, message: '请输入物品名称', trigger: 'blur' },
        { min: 1, max: 50, message: '物品名称长度不能超过50个字符', trigger: 'blur' }
      ],
      type: [
        { required: true, message: '请选择物品类型', trigger: 'change' }
      ],
      location: [
        { required: true, message: '请输入丢失地点', trigger: 'blur' },
        { min: 1, max: 100, message: '丢失地点长度不能超过100个字符', trigger: 'blur' }
      ],
      description: [
        { required: true, message: '请输入物品描述', trigger: 'blur' },
        { min: 5, max: 500, message: '物品描述长度在5-500个字符之间', trigger: 'blur' }
      ],
      contactName: [
        { required: true, message: '请输入联系人姓名', trigger: 'blur' },
        { min: 1, max: 20, message: '联系人姓名长度不能超过20个字符', trigger: 'blur' }
      ],
      contactPhone: [
        { required: true, message: '请输入联系电话', trigger: 'blur' },
        { pattern: /^1[3-9]\d{9}$/, message: '请输入正确的手机号码', trigger: 'blur' }
      ],
      contactEmail: [
        { pattern: /^[^\s@]+@[^\s@]+\.[^\s@]+$/, message: '请输入正确的邮箱地址', trigger: 'blur' }
      ]
    };
    
    // 处理图片变化
    const handleImagesChange = (images) => {
      lostForm.images = images;
      
    };
    
    // 提交表单
    const handleSubmit = async () => {
      if (!lostFormRef.value) return;
      
      try {
        await lostFormRef.value.validate();
        loading.value = true;
        
        // 提交数据
        const res = await publishLost({
          ...lostForm,
           images: JSON.stringify(lostForm.images) 
        });
        
        ElMessage.success('失物信息发布成功，等待审核通过后将显示在列表中');
        emit('submit-success', res.data);
        
        // 重置表单
        handleReset();
      } catch (error) {
        if (error !== false) { // 排除表单验证失败的情况
          ElMessage.error('发布失败：' + (error.message || '未知错误'));
        }
      } finally {
        loading.value = false;
      }
    };
    
    // 重置表单
    const handleReset = () => {
      if (lostFormRef.value) {
        lostFormRef.value.resetFields();
      }
      
      // 重置图片
      lostForm.images = [];
    };
    
    return {
      lostFormRef,
      loading,
      lostForm,
      rules,
      categories,
      handleImagesChange,
      handleSubmit,
      handleReset,
      token,
      handleUploadError,
      handleUploadSuccess
    };
  }
};
</script>

<style scoped>
/* 组件样式可以根据需要调整 */
.el-form {
  max-width: 800px;
  margin: 0 auto;
}

.el-form-item {
  margin-bottom: 24px;
}

/* 响应式设计 */
@media (max-width: 768px) {
  .el-form {
    max-width: 100%;
  }
  
  .el-form-item {
    margin-bottom: 20px;
  }
}
</style>