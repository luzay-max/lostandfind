<template>
  <el-form ref="findFormRef" :model="findForm" :rules="rules" label-width="120px" v-loading="loading">
    <el-form-item label="物品名称" prop="name">
      <el-input v-model="findForm.name" placeholder="请输入物品名称" maxlength="50"></el-input>
    </el-form-item>

<el-form-item label="物品类型" prop="type">
  <el-select v-model="findForm.type" placeholder="请选择物品类型">
    <el-option
      v-for="category in categories"
      :key="category.value"
      :label="category.label"
      :value="category.value"
    ></el-option>
  </el-select>
</el-form-item>

<el-form-item label="拾取地点" prop="location">
  <el-input v-model="findForm.location" placeholder="请输入详细的拾取地点" maxlength="100"></el-input>
</el-form-item>

<el-form-item label="物品描述" prop="description">
  <el-input
    v-model="findForm.description"
    type="textarea"
    placeholder="请详细描述物品特征（如颜色、品牌、外观等）"
    :rows="4"
    maxlength="500"
  ></el-input>
</el-form-item>

<el-form-item label="联系人姓名" prop="contactName">
  <el-input v-model="findForm.contactName" placeholder="请输入联系人姓名" maxlength="20"></el-input>
</el-form-item>

<el-form-item label="联系电话" prop="contactPhone">
  <el-input v-model="findForm.contactPhone" placeholder="请输入联系电话" maxlength="11"></el-input>
</el-form-item>

<el-form-item label="联系邮箱" prop="contactEmail">
  <el-input v-model="findForm.contactEmail" placeholder="请输入联系邮箱" maxlength="50"></el-input>
</el-form-item>

<el-form-item label="物品图片">
  <el-upload
    :headers="{ Authorization: `${token}` }"
    action="/api/user/uploadImage"
    name="file"
    list-type="picture-card"
    :on-success="handleUploadSuccess"
    :on-error="handleUploadError"
    :limit="9"
    multiple
  >
    <i class="el-icon-plus"></i>
  </el-upload>
</el-form-item>

<el-form-item>
  <el-button type="primary" @click="handleSubmit" :loading="loading">发布招领信息</el-button>
  <el-button @click="handleReset">重置</el-button>
</el-form-item>


  </el-form>
</template>

<script>
import { ref, reactive } from 'vue';
import { ElMessage } from 'element-plus';
import { publishFind } from '../../api/findApi';
import { getToken } from '../../utils/authUtil';

export default {
  name: 'FindForm',
  emits: ['submit-success'],
  setup(props, { emit }) {
    const findFormRef = ref(null);
    const loading = ref(false);
    const token = getToken();

    // 物品分类
    const categories = [
      { label: '证件', value: 'ID_CARD' },
      { label: '电子产品', value: 'ELECTRONICS' },
      { label: '书籍文具', value: 'BOOKS' },
      { label: '衣物', value: 'CLOTHES' },
      { label: '生活用品', value: 'DAILY_NECESSITIES' },
      { label: '其他', value: 'OTHER' }
    ];

    // 表单数据
    const findForm = reactive({
      name: '',
      type: '',
      location: '',
      description: '',
      contactName: '',
      contactPhone: '',
      contactEmail: '',
      images: []
    });

    // 表单验证规则
    const rules = {
      name: [
        { required: true, message: '请输入物品名称', trigger: 'blur' },
        { min: 1, max: 50, message: '物品名称长度不能超过50个字符', trigger: 'blur' }
      ],
      type: [
        { required: true, message: '请选择物品类型', trigger: 'change' }
      ],
      location: [
        { required: true, message: '请输入拾取地点', trigger: 'blur' },
        { min: 1, max: 100, message: '拾取地点长度不能超过100个字符', trigger: 'blur' }
      ],
      description: [
        { required: true, message: '请输入物品描述', trigger: 'blur' },
        { min: 5, max: 500, message: '物品描述长度在5-500个字符之间', trigger: 'blur' }
      ],
      contactName: [
        { required: true, message: '请输入联系人姓名', trigger: 'blur' },
        { min: 1, max: 20, message: '联系人姓名长度不能超过20个字符', trigger: 'blur' }
      ],
      contactPhone: [
        { required: true, message: '请输入联系电话', trigger: 'blur' },
        { pattern: /^1[3-9]\d{9}$/, message: '请输入正确的手机号码', trigger: 'blur' }
      ],
      contactEmail: [
        { pattern: /^[^\s@]+@[^\s@]+\.[^\s@]+$/, message: '请输入正确的邮箱地址', trigger: 'blur' }
      ]
    };

    // 图片上传成功
    const handleUploadSuccess = (res) => {
      findForm.images.push(res.data);
    };

    // 图片上传失败
    const handleUploadError = () => {
      ElMessage.error('图片上传失败');
    };

    // 提交表单
    const handleSubmit = async () => {
      if (!findFormRef.value) return;

      try {
        await findFormRef.value.validate();
        loading.value = true;

        const res = await publishFind({
          ...findForm,
          images: JSON.stringify(findForm.images)
        });

        ElMessage.success('招领信息发布成功，等待审核通过后将显示在列表中');
        emit('submit-success', res.data);

        handleReset();
      } catch (error) {
        if (error !== false) {
          ElMessage.error('发布失败：' + (error.message || '未知错误'));
        }
      } finally {
        loading.value = false;
      }
    };

    // 重置表单
    const handleReset = () => {
      if (findFormRef.value) findFormRef.value.resetFields();
      findForm.images = [];
    };

    return {
      findFormRef,
      loading,
      findForm,
      rules,
      categories,
      handleUploadSuccess,
      handleUploadError,
      handleSubmit,
      handleReset,
      token
    };
  }
};
</script>

<style scoped>
.el-form {
  max-width: 800px;
  margin: 0 auto;
}

.el-form-item {
  margin-bottom: 24px;
}

@media (max-width: 768px) {
  .el-form {
    max-width: 100%;
  }
  
  .el-form-item {
    margin-bottom: 20px;
  }
}
</style>
