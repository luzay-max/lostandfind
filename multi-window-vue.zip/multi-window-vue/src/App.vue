<template>
  <div class="app-container">
    <!-- 导航栏 -->
    <Navbar />
    
    <!-- 主内容区 -->
    <main class="main-content">
      <router-view v-slot="{ Component }">
        <transition name="fade" mode="out-in">
          <component :is="Component" />
        </transition>
      </router-view>
    </main>
    
    <!-- 页脚 -->
    <footer class="footer">
      <div class="footer-content">
        <p>© 2024 校园失物招领平台 - 让每一件失物都能回家</p>
      </div>
    </footer>
  </div>
</template>

<script>
import { onMounted } from 'vue';
import { useUserStore } from './store/userStore';
import Navbar from './components/common/Navbar.vue';

export default {
  name: 'App',
  components: {
    Navbar
  },
  setup() {
    const userStore = useUserStore();
    
    // 应用启动时尝试从本地存储恢复登录状态
    onMounted(() => {
      userStore.checkLoginStatus();
    });
    
    return {};
  }
};
</script>

<style>
/* 全局样式重置 */
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

body {
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
  background-color: #f5f7fa;
  color: #303133;
  line-height: 1.6;
}

/* 变量定义 */
:root {
  --primary-color: #409eff;
  --primary-dark: #337ecc;
  --success-color: #67c23a;
  --warning-color: #e6a23c;
  --danger-color: #f56c6c;
  --info-color: #909399;
  --text-primary: #303133;
  --text-regular: #606266;
  --text-secondary: #909399;
  --text-placeholder: #c0c4cc;
  --border-color: #dcdfe6;
  --border-light: #ebeef5;
  --background-color: #f5f7fa;
  --box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
}

/* 应用容器 */
.app-container {
  min-height: 100vh;
  display: flex;
  flex-direction: column;
}

/* 主内容区 */
.main-content {
  flex: 1;
  margin-bottom: 60px;
}

/* 页脚 */
.footer {
  background-color: #ffffff;
  border-top: 1px solid var(--border-light);
  padding: 20px 0;
  text-align: center;
  position: relative;
  margin-top: auto;
}

.footer-content {
  max-width: 1400px;
  margin: 0 auto;
  padding: 0 20px;
}

.footer p {
  color: var(--text-secondary);
  font-size: 14px;
}

/* 页面过渡动画 */
.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.3s ease;
}

.fade-enter-from,
.fade-leave-to {
  opacity: 0;
}

/* 响应式设计 */
@media (max-width: 768px) {
  .main-content {
    margin-bottom: 40px;
  }
  
  .footer {
    padding: 15px 0;
  }
  
  .footer p {
    font-size: 12px;
  }
}
</style>
