import request from './request';

// 用户登录
export const login = async (data) => {
  // 使用URLSearchParams序列化表单数据
  const params = new URLSearchParams();
  params.append('username', data.username);
  params.append('password', data.password);
  return request({
    url: 'auth/login',
    method: 'post',
    data: params,
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
  
  });
};

// 用户注册
export const register = (data) => {
  return request({
    url: '/auth/register',
    method: 'post',
    data
  });
};

// 获取用户信息
export const getUserInfo = async () => {
  // 直接调用实际API
  return request({
    url: '/user/info',
    method: 'get'
  });
};

// 更新用户信息
export const updateUserInfo = (data) => {
  return request({
    url: '/user/update',
    method: 'post',
    data
  });
};

// 更新用户头像
export const updateAvatar = (file) => {
  const formData = new FormData();
  formData.append('avatar', file); // 参数名必须为'avatar'
  return request({
    url: '/user/updateAvatar',
    method: 'post',
    data: formData,
    //  headers: { 'Content-Type': 'multipart/form-data' } 这个可以加或者不加
  
  });
};
