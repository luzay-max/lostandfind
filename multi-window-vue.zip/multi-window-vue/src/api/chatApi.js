import request from './request';

// 留言
export const leaveMessage = (data) => {
  return request({
    url: '/chat/leaveMessage',
    method: 'post',
    data
  });
};

// 回复留言
export const replyMessage = (data) => {
  return request({
    url: '/chat/replyMessage',
    method: 'post',
    data
  });
};

// 获取留言列表
export const getMessageList = (params) => {
  return request({
    url: '/chat/messageList',
    method: 'get',
    params
  });
};

// 删除留言
export const deleteMessage = (id) => {
  return request({
    url: `/chat/deleteMessage/${id}`,
    method: 'post'
  });
};

// 获取用户收到的消息通知
export const getNotifications = (params) => {
  return request({
    url: '/chat/notifications',
    method: 'get',
    params
  });
};

// 标记消息已读
export const markAsRead = (id) => {
  return request({
    url: `/chat/markAsRead/${id}`,
    method: 'post'
  });
};