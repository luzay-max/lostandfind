import axios from 'axios';
import { ElMessage } from 'element-plus';
import { useUserStore } from '../store/userStore';
import router from '../router';

// 创建 axios 实例
const service = axios.create({
  baseURL: import.meta.env.VITE_APP_BASE_API || '/api',
  timeout: 10000
  // 移除默认的Content-Type，让浏览器根据请求类型自动设置
});

// 请求拦截器
service.interceptors.request.use(
  (config) => {
    // 从 store 获取 token
    const userStore = useUserStore();
    const token = userStore.token;
    
    // 如果 token 存在，添加到请求头
    if (token) {
      config.headers['Authorization'] = `${token}`;
    }
    
    return config;
  },
  (error) => {
    console.error('请求错误:', error);
    return Promise.reject(error);
  }
);

// 响应拦截器
service.interceptors.response.use(
  (response) => {
    const res = response.data;
    
    // 根据后端约定的状态码处理
    if (res.code !== 0) {
      // 错误提示
      ElMessage.error(res.message || '请求失败');
      
      // 处理特殊错误码
      if (res.code === 401) {
        // 未登录或 token 失效，清除登录状态并重定向到登录页
        const userStore = useUserStore();
        userStore.logout();
        router.push('/login');
      }
      
      return Promise.reject(new Error(res.message || '请求失败'));
    }
    
    return res;
  },
  (error) => {
    // 网络错误处理
    // 静默处理请求取消的情况，避免控制台不必要的错误日志
    if (error && error.code === 'ECONNABORTED') {
      return Promise.reject(error);
    }
    
    let errorMsg = '网络请求失败';
    if (error.response) {
      // 服务器返回错误
      switch (error.response.status) {
        case 400:
          errorMsg = '请求参数错误';
          break;
        case 401:
          errorMsg = '未授权，请重新登录';
          // 清除登录状态并重定向到登录页
          const userStore = useUserStore();
          userStore.logout();
          router.push('/login');
          break;
        case 403:
          errorMsg = '拒绝访问';
          break;
        case 404:
          errorMsg = '请求的资源不存在';
          break;
        case 500:
          errorMsg = '服务器内部错误';
          break;
        default:
          errorMsg = error.response.data?.message || `请求失败(${error.response.status})`;
      }
    } else if (error.request) {
      // 请求已发送但没有收到响应
      errorMsg = '网络连接失败，请检查网络';
    }
    
    ElMessage.error(errorMsg);
    // 优化错误对象，优先使用服务器返回的错误信息
    if (error && error.response && error.response.data && error.response.data.message) {
      return Promise.reject(new Error(error.response.data.message));
    }
    return Promise.reject(error);
  }
);

export default service;