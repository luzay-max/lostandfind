import request from './request';

// 用户登录
export const login = (data) => {
  return request.post('/auth/login', data);
};

// 用户注册
export const register = (data) => {
  return request.post('/auth/register', data);
};

// 用户登出
export const logout = () => {
  return request.post('/auth/logout');
};

// 获取用户信息
export const getUserInfo = () => {
  return request.get('/user/info');
};

// 更新用户信息
export const updateUserInfo = (data) => {
  return request.put('/auth/update', data);
};

// 重置密码
export const resetPassword = (data) => {
  return request.post('/auth/resetPassword', data);
};

// 发送验证码
export const sendCode = (email) => {
  return request.post('/auth/sendCode', { email });
};

// 验证邮箱
export const verifyEmail = (data) => {
  return request.post('/auth/verifyEmail', data);
};