import request from './request';

// 获取待审核信息列表
export const getAuditList = (params) => {
  return request({
    url: '/audit/list',
    method: 'get',
    params
  });
};

// 审核通过
export const auditPass = (data) => {
  return request({
    url: '/audit/pass',
    method: 'post',
    data
  });
};

// 审核通过的别名（兼容其他组件使用）
export const auditApprove = auditPass;

// 批量审核通过
export const batchAuditApprove = (data) => {
  return request({
    url: '/audit/batchPass',
    method: 'post',
    data
  });
};

// 审核驳回
export const auditReject = (data) => {
  return request({
    url: '/audit/reject',
    method: 'post',
    data
  });
};

// 获取审核历史记录
export const getAuditHistory = (params) => {
  return request({
    url: '/audit/history',
    method: 'get',
    params
  });
};

// 获取审核统计数据
export const getAuditStats = () => {
  return request({
    url: '/audit/stats',
    method: 'get'
  });
};

// 获取管理员统计信息
export const getAdminStatistics = () => {
  return request({
    url: '/admin/statistics',
    method: 'get'
  });
};

// 获取最近的项目
export const getRecentItems = (params) => {
  return request({
    url: '/admin/recentItems',
    method: 'get',
    params
  });
};