import axios from 'axios';
import { ElMessage, ElMessageBox } from 'element-plus';
import { getToken, removeToken } from './authUtil';

// 创建axios实例
const service = axios.create({
// `import.meta.env.VITE_APP_BASE_API` 的值取决于环境配置，若未配置则默认值为 '/'
  baseURL: import.meta.env.VITE_APP_BASE_API || '/',
  timeout: 10000
});

// 请求拦截器
service.interceptors.request.use(
  config => {
    // 从本地存储获取token
    const token = getToken();
    if (token) {
      config.headers['Authorization'] = `${token}`;
    }

    // ✅ 动态设置 Content-Type
    if (config.data instanceof FormData) {
      // 上传文件时，让浏览器自动处理 multipart 边界
      delete config.headers['Content-Type'];
    } else if (!config.headers['Content-Type']) {
      // 普通请求默认使用 JSON
      config.headers['Content-Type'] = 'application/json';
    }

    return config;
  },
  error => {
    console.error('请求错误:', error);
    return Promise.reject(error);
  }
);


// 响应拦截器
service.interceptors.response.use(
  response => {
    const res = response.data;
    
    // 判断响应状态码
    if (res.code !== 0) {
      // 错误提示
      ElMessage.error(res.message || '请求失败');
      
      // 处理未登录情况
      if (res.code === 401) {
        ElMessageBox.confirm('您已被登出，请重新登录', '提示', {
          confirmButtonText: '重新登录',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          removeToken();
          window.location.href = '/login';
        });
      }
      
      return Promise.reject(new Error(res.message || '请求失败'));
    }
    
    return res;
  },
  error => {
    console.error('响应错误:', error);
    
    let message = '网络异常，请稍后重试';
    if (error.response) {
      switch (error.response.status) {
        case 401:
          message = '未授权，请重新登录';
          removeToken();
          window.location.href = '/login';
          break;
        case 403:
          message = '拒绝访问';
          break;
        case 404:
          message = '请求的资源不存在';
          break;
        case 500:
          message = '服务器内部错误';
          break;
        default:
          message = error.response.data.message || message;
      }
    }
    
    ElMessage.error(message);
    return Promise.reject(error);
  }
);

export default service;