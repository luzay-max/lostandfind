import { createApp } from 'vue'
import './style.css'
import ElementPlus from 'element-plus'
import 'element-plus/dist/index.css'
import zhCn from 'element-plus/dist/locale/zh-cn.mjs'
import * as ElementPlusIconsVue from '@element-plus/icons-vue'
import { createPinia } from 'pinia'
import router from './router'
import App from './App.vue'

// API测试工具暂时移除，避免影响应用启动
// 如需使用测试工具，请在需要测试的组件中单独导入使用
// if (import.meta.env.DEV) {
//   try {
//     import('./utils/apiTestUtil.js').then(module => {
//       window.apiTestUtil = module.default || module;
//       console.log('API测试工具已加载成功');
//     });
//   } catch (err) {
//     console.error('API测试工具加载失败:', err);
//   }
// }

// 处理 ResizeObserver 错误
const resizeObserverLoopErr = () => {
  const resizeObserverErr = window.ResizeObserver;
  window.ResizeObserver = class ResizeObserver extends resizeObserverErr {
    constructor(callback) {
      callback = debounce(callback, 16);
      super(callback);
    }
  };
};

// 防抖函数
function debounce(fn, delay) {
  let timer = null;
  return function () {
    if (timer) clearTimeout(timer);
    timer = setTimeout(() => {
      fn.apply(this, arguments);
    }, delay);
  };
}

// 尝试处理 ResizeObserver 错误
try {
  resizeObserverLoopErr();
} catch (e) {
  // 忽略错误
}

// 创建 Vue 应用实例
const app = createApp(App)

// 注册Element Plus图标
for (const [key, component] of Object.entries(ElementPlusIconsVue)) {
  app.component(key, component)
}

app.use(ElementPlus, {
  locale: zhCn,
})
const pinia = createPinia()

app.use(pinia)
app.use(router)

// 挂载应用
app.mount('#app')
